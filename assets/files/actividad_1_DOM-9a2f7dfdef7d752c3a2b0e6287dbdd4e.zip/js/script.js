// Escribe tus comandos aquí si lo prefieres.
console.log("¡Bienvenido a Stardew DOM!");
