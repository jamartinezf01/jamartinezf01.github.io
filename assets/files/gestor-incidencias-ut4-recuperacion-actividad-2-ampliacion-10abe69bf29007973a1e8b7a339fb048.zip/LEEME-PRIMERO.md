# Recuperación para la Actividad 3 · Consultas y paginación

Este ZIP incluye el proyecto **gestor_incidencias/**, preparado como punto de partida después de la **Actividad 2. Ampliación: una imagen también explica el problema**.

1. Abre la carpeta `gestor_incidencias/` en IntelliJ IDEA (Java 21, Spring Boot 4.1.2).
2. Revisa `gestor_incidencias/README-RECUPERACION.md`, especialmente la configuración de `DB_PASSWORD` y `IMAGENES_DIR`.
3. Conserva la base de datos `gestor_incidencias` que ya utilizabas. Si no existe, ejecuta `preparacion-bd.sql` con una cuenta administradora; no vuelvas a ejecutarlo para reemplazar una base funcional.
4. Comprueba el CRUD y que puedes adjuntar, ver, sustituir y quitar fotografías de una incidencia. El proyecto no incluye fotografías previamente subidas.
5. Ejecuta `datos-prueba-actividad-03.sql` en la BD una vez que Hibernate haya creado la tabla. El script incorpora 48 incidencias **sin fotografía**, no elimina datos previos ni debe duplicar sus ejemplos cuando se repite.
6. Desarrolla desde aquí los filtros, consultas JPQL, ordenación y paginación que pide la Actividad 3. **No están implementados** en este proyecto.

El proyecto se ha generado a partir de la recuperación original de la Actividad 2 y se ha ampliado con persistencia de imágenes **en el sistema de archivos**, no en columnas BLOB.
