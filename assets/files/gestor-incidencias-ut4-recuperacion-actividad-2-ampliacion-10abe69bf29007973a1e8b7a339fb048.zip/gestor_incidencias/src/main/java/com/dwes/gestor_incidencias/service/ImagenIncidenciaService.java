package com.dwes.gestor_incidencias.service;

import com.dwes.gestor_incidencias.model.Incidencia;
import com.dwes.gestor_incidencias.repository.IncidenciaRepository;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Optional;

/** Coordina la referencia persistente con el archivo almacenado en disco. */
@Service
public class ImagenIncidenciaService {

    private final IncidenciaRepository repositorio;
    private final AlmacenamientoImagenesService archivos;

    public ImagenIncidenciaService(IncidenciaRepository repositorio, AlmacenamientoImagenesService archivos) {
        this.repositorio = repositorio;
        this.archivos = archivos;
    }

    public boolean guardarOReemplazar(Long id, MultipartFile imagen) throws IOException {
        Optional<Incidencia> resultado = repositorio.findById(id);
        if (resultado.isEmpty()) return false;

        Incidencia incidencia = resultado.get();
        // Guardamos y validamos el nuevo archivo antes de tocar el anterior.
        String nombreNuevo = archivos.guardar(imagen);
        String nombreAnterior = incidencia.getImagenNombre();
        try {
            incidencia.setImagenNombre(nombreNuevo);
            repositorio.saveAndFlush(incidencia);
        } catch (RuntimeException e) {
            archivos.borrarSiExiste(nombreNuevo); // Evitamos un archivo huérfano si falla MySQL.
            throw e;
        }
        // La nueva referencia ya se ha confirmado en MySQL.
        archivos.borrarSiExiste(nombreAnterior);
        return true;
    }

    public boolean quitar(Long id) {
        Optional<Incidencia> resultado = repositorio.findById(id);
        if (resultado.isEmpty()) return false;
        Incidencia incidencia = resultado.get();
        String anterior = incidencia.getImagenNombre();
        if (anterior == null) return true;
        incidencia.setImagenNombre(null);
        repositorio.saveAndFlush(incidencia);
        archivos.borrarSiExiste(anterior);
        return true;
    }

    public Resource recuperar(Long id) throws MalformedURLException {
        Optional<Incidencia> incidencia = repositorio.findById(id);
        if (incidencia.isEmpty() || incidencia.get().getImagenNombre() == null) return null;
        return archivos.recuperar(incidencia.get().getImagenNombre());
    }

    public String tipoMime(Long id) {
        return repositorio.findById(id)
                .map(Incidencia::getImagenNombre)
                .filter(nombre -> !nombre.isBlank())
                .map(archivos::tipoMime)
                .orElse("application/octet-stream");
    }
}
