package com.dwes.gestor_incidencias.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

/** La peticion no llega al controlador si excede el limite multipart de Spring. */
@ControllerAdvice(annotations = Controller.class)
public class ImagenExcepcionController {

    @ExceptionHandler(MaxUploadSizeExceededException.class)
    @ResponseStatus(HttpStatus.PAYLOAD_TOO_LARGE)
    public String imagenDemasiadoGrande(MaxUploadSizeExceededException ex,
                                        HttpServletRequest request, Model model) {
        model.addAttribute("mensaje", "El archivo enviado supera el tamaño máximo permitido. " +
                "Selecciona una imagen JPEG o PNG de como máximo 1 MB.");
        return "error-imagen";
    }
}
