package com.dwes.gestor_incidencias.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;

@Entity
@Table(name = "incidencias")
public class Incidencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Introduce un título.")
    @Size(min = 5, max = 100, message = "El título debe tener entre 5 y 100 caracteres.")
    @Column(nullable = false, length = 100)
    private String titulo;

    @NotBlank(message = "Introduce una descripción.")
    @Size(min = 10, max = 500, message = "La descripción debe tener entre 10 y 500 caracteres.")
    @Column(nullable = false, length = 500)
    private String descripcion;

    @NotBlank(message = "Selecciona una prioridad.")
    @Pattern(regexp = "BAJA|MEDIA|ALTA", message = "La prioridad no es válida.")
    @Column(nullable = false, length = 10)
    private String prioridad;

    @NotBlank(message = "Selecciona un estado.")
    @Pattern(regexp = "ABIERTA|EN_PROCESO|RESUELTA", message = "El estado no es válido.")
    @Column(nullable = false, length = 15)
    private String estado = "ABIERTA";

    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro;

    // La imagen se guarda en disco. MySQL solo conserva este nombre.
    @Column(name = "imagen_nombre", length = 80)
    private String imagenNombre;

    public Incidencia() { }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getPrioridad() { return prioridad; }
    public void setPrioridad(String prioridad) { this.prioridad = prioridad; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public LocalDate getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(LocalDate fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public String getImagenNombre() { return imagenNombre; }
    public void setImagenNombre(String imagenNombre) { this.imagenNombre = imagenNombre; }
}
