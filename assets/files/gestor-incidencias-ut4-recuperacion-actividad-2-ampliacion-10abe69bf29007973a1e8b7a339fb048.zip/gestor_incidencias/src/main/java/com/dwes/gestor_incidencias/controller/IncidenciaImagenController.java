package com.dwes.gestor_incidencias.controller;

import com.dwes.gestor_incidencias.service.ImagenIncidenciaService;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;

@Controller
public class IncidenciaImagenController {

    private final ImagenIncidenciaService imagenes;

    public IncidenciaImagenController(ImagenIncidenciaService imagenes) {
        this.imagenes = imagenes;
    }

    @PostMapping("/incidencias/{id}/imagen")
    public String subir(@PathVariable Long id,
                        @RequestParam("imagen") MultipartFile imagen,
                        RedirectAttributes redirect, Model model) {
        try {
            if (!imagenes.guardarOReemplazar(id, imagen)) return noEncontrada(id, model);
            redirect.addFlashAttribute("imagenOk", "Fotografía guardada correctamente.");
        } catch (IllegalArgumentException e) {
            redirect.addFlashAttribute("imagenError", e.getMessage());
        } catch (IOException e) {
            redirect.addFlashAttribute("imagenError", "No se ha podido guardar la imagen. Comprueba el directorio.");
        }
        return "redirect:/incidencias/" + id;
    }

    @GetMapping("/incidencias/{id}/imagen")
    public ResponseEntity<Resource> ver(@PathVariable Long id) throws IOException {
        Resource imagen = imagenes.recuperar(id);
        if (imagen == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(imagenes.tipoMime(id)))
                .body(imagen);
    }

    @PostMapping("/incidencias/{id}/imagen/eliminar")
    public String quitar(@PathVariable Long id, RedirectAttributes redirect, Model model) {
        if (!imagenes.quitar(id)) return noEncontrada(id, model);
        redirect.addFlashAttribute("imagenOk", "Fotografía retirada.");
        return "redirect:/incidencias/" + id;
    }

    private String noEncontrada(Long id, Model model) {
        model.addAttribute("mensaje", "No existe ninguna incidencia con identificador " + id + ".");
        return "incidencia-no-encontrada";
    }
}
