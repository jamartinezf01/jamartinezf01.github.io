package com.dwes.gestor_incidencias.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Iterator;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Almacena imágenes fuera del proyecto. Nunca utiliza rutas enviadas por el navegador. */
@Service
public class AlmacenamientoImagenesService {

    public static final long TAMANO_MAXIMO = 1024 * 1024; // 1 MiB
    private static final long PIXELES_MAXIMOS = 12_000_000L;
    private static final Logger LOG = Logger.getLogger(AlmacenamientoImagenesService.class.getName());
    private final Path directorio;

    public AlmacenamientoImagenesService(@Value("${app.imagenes.directorio}") String ruta) throws IOException {
        if (ruta == null || ruta.isBlank()) {
            throw new IllegalArgumentException("Es necesario configurar IMAGENES_DIR.");
        }
        this.directorio = Path.of(ruta).toAbsolutePath().normalize();
        Files.createDirectories(this.directorio);
        if (!Files.isDirectory(this.directorio) || !Files.isWritable(this.directorio)) {
            throw new IOException("El directorio de imágenes no permite escritura: " + this.directorio);
        }
    }

    /** Devuelve únicamente el nombre generado, que es lo que se almacenará en MySQL. */
    public String guardar(MultipartFile imagen) throws IOException {
        if (imagen == null || imagen.isEmpty()) {
            throw new IllegalArgumentException("Debes seleccionar una fotografía.");
        }
        if (imagen.getSize() > TAMANO_MAXIMO) {
            throw new IllegalArgumentException("La fotografía no puede superar 1 MB.");
        }
        byte[] contenido = imagen.getBytes();
        if (contenido.length == 0 || contenido.length > TAMANO_MAXIMO) {
            throw new IllegalArgumentException("La fotografía está vacía o supera 1 MB.");
        }
        String extension = identificarImagen(contenido);
        String nombre = UUID.randomUUID() + "." + extension;
        Files.write(rutaSegura(nombre), contenido, StandardOpenOption.CREATE_NEW);
        return nombre;
    }

    /** El formato se detecta a partir del contenido real, no del nombre ni del MIME recibido. */
    private String identificarImagen(byte[] contenido) throws IOException {
        try (ImageInputStream entrada = ImageIO.createImageInputStream(new ByteArrayInputStream(contenido))) {
            if (entrada == null) {
                throw new IllegalArgumentException("El archivo no es una imagen JPEG o PNG válida.");
            }
            Iterator<ImageReader> lectores = ImageIO.getImageReaders(entrada);
            if (!lectores.hasNext()) {
                throw new IllegalArgumentException("El archivo no es una imagen JPEG o PNG válida.");
            }
            ImageReader lector = lectores.next();
            try {
                lector.setInput(entrada);
                String formato = lector.getFormatName();
                String extension;
                if ("JPEG".equalsIgnoreCase(formato) || "JPG".equalsIgnoreCase(formato)) {
                    extension = "jpg";
                } else if ("PNG".equalsIgnoreCase(formato)) {
                    extension = "png";
                } else {
                    throw new IllegalArgumentException("Solo se admiten imágenes JPEG y PNG.");
                }
                long ancho = lector.getWidth(0);
                long alto = lector.getHeight(0);
                if (ancho <= 0 || alto <= 0 || ancho * alto > PIXELES_MAXIMOS) {
                    throw new IllegalArgumentException("La imagen tiene dimensiones no permitidas.");
                }
                // Una cabecera reconocible no es suficiente: hay que poder decodificarla.
                if (lector.read(0) == null) {
                    throw new IllegalArgumentException("El archivo no contiene una imagen válida.");
                }
                return extension;
            } catch (IOException | IndexOutOfBoundsException e) {
                throw new IllegalArgumentException("No se ha podido leer la imagen. Comprueba el archivo.", e);
            } finally {
                lector.dispose();
            }
        }
    }

    public Resource recuperar(String nombre) throws MalformedURLException {
        Path ruta = rutaSegura(nombre);
        if (!Files.isRegularFile(ruta, LinkOption.NOFOLLOW_LINKS) || !Files.isReadable(ruta)) {
            return null;
        }
        return new UrlResource(ruta.toUri());
    }

    public String tipoMime(String nombre) {
        rutaSegura(nombre);
        return nombre.endsWith(".png") ? "image/png" : "image/jpeg";
    }

    /** Si el disco falla al eliminar, dejamos una advertencia para poder recuperar el archivo. */
    public void borrarSiExiste(String nombre) {
        if (nombre == null || nombre.isBlank()) return;
        try {
            Files.deleteIfExists(rutaSegura(nombre));
        } catch (IOException e) {
            LOG.log(Level.WARNING, "No se pudo eliminar una fotografía antigua: " + nombre, e);
        }
    }

    private Path rutaSegura(String nombre) {
        if (nombre == null || !nombre.matches("[0-9a-f-]{36}\\.(jpg|png)")) {
            throw new IllegalArgumentException("Referencia de imagen no válida.");
        }
        Path ruta = directorio.resolve(nombre).normalize();
        if (!ruta.getParent().equals(directorio)) {
            throw new IllegalArgumentException("Referencia de imagen no válida.");
        }
        return ruta;
    }
}
