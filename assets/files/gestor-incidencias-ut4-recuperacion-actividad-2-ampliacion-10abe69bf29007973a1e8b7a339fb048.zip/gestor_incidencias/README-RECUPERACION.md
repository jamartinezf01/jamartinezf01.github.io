# Gestor de incidencias · Recuperación tras la actividad de ampliación (UT4)

Este proyecto contiene la **solución de partida esperada tras la Actividad 2 y su ampliación de imágenes**, para quienes no hayan conseguido completar ese trabajo. Si tu propio gestor funciona, **continúa con él** y no reemplaces tus datos ni código.

## Funcionalidades que ya están implementadas

- `Incidencia` con mapeo JPA y anotaciones de validación.
- `IncidenciaRepository` y **capa `IncidenciaService`**.
- Listado, alta, ficha de detalle, edición y eliminación con Spring MVC y Thymeleaf.
- Verificación de restricciones y mensajes de error en los formularios.
- Gestión de identificadores inexistentes.
- CSS y conexión MySQL mediante la variable `DB_PASSWORD`.
- Fotografías JPEG y PNG guardadas en un directorio externo configurado mediante `IMAGENES_DIR`.
- Asociación de una imagen opcional por incidencia mediante `imagen_nombre` en MySQL.
- Subida, validación, visualización, sustitución y retirada de fotografías; limpieza al eliminar incidencias.

## Qué NO está implementado (es el trabajo de la actividad 3)

- Filtro de título, prioridad y estado, individuales o combinados.
- Métodos derivados y consultas JPQL de búsqueda.
- Selección de orden, ordenación múltiple y paginación.
- Navegación entre páginas conservando los filtros.

## Puesta en marcha

1. Abre la carpeta `gestor_incidencias` desde IntelliJ IDEA gratuito y usa **Java 21**.
2. Importa las dependencias Maven del `pom.xml` (Spring Boot **4.1.2**).
3. Inicia MySQL en `localhost:3306` y configura la variable `DB_PASSWORD` con la contraseña de `incidencias_app`.
4. Configura `IMAGENES_DIR` como un directorio **externo al proyecto** (por ejemplo, `C:/datos/gestor-incidencias/imagenes`). Debe existir o poder crearse y permitir escritura. No guardes las fotografías en `src/main/resources/static`.
5. Si todavía no existe la base de datos, utiliza `preparacion-bd.sql` **con una cuenta administradora** y sustituye la contraseña de ejemplo. No ejecutes el script si ya tienes la base preparada.
6. Ejecuta `GestorIncidenciasApplication` y comprueba `http://localhost:8080/incidencias`.
7. Antes de trabajar en la actividad 3, verifica que puedes dar de alta, editar, consultar y eliminar una incidencia. Desde su detalle, adjunta una imagen JPEG o PNG, comprueba que aparece y prueba a quitarla. Las incidencias sin imagen deben funcionar igualmente.
8. Utiliza el archivo **`datos-prueba-actividad-03.sql`** del ZIP para cargar casos de prueba; no borra registros existentes y puedes ejecutarlo de nuevo sin duplicar esos casos.

**La actividad 3 debe desarrollarse sobre este proyecto** si utilizas la recuperación. Entregar la recuperación sin modificar no cumple los requisitos.

## Dependencias incluidas

- `spring-boot-starter-webmvc`.
- `spring-boot-starter-thymeleaf`.
- `spring-boot-starter-data-jpa`.
- `spring-boot-starter-validation`.
- `mysql-connector-j`.
- `spring-boot-starter-test` (ámbito test).

El `pom.xml` conserva todas las dependencias necesarias para filtros, JPQL, ordenación y paginación: Spring Data JPA ya proporciona las interfaces `Page`, `Pageable`, `PageRequest` y `Sort`, por lo que **no es necesario añadir otra dependencia**.

### Nota sobre Maven

Se incluye el mismo lanzador `mvnw.cmd` utilizado en la recuperación anterior. En Windows descarga Maven si no lo encuentra (requiere conexión a Internet la primera vez). También puedes utilizar la ventana de Maven de IntelliJ IDEA.

## Comprobaciones de imágenes

- `GET /incidencias/{id}` incluye un formulario independiente para adjuntar o sustituir una fotografía.
- `POST /incidencias/{id}/imagen` admite una imagen JPEG o PNG real de hasta 1 MiB, guardada en `IMAGENES_DIR`.
- `GET /incidencias/{id}/imagen` devuelve el recurso físico correspondiente, o HTTP 404 si no existe.
- `POST /incidencias/{id}/imagen/eliminar` retira la imagen y conserva la incidencia.
- Al eliminar una incidencia, también se intenta retirar su archivo asociado.
- La edición de texto conserva la propiedad `imagenNombre`.

La carpeta configurada en `IMAGENES_DIR` **no está incluida en el ZIP** y no es necesario entregar imágenes de prueba. Si se usa una base de datos previa con referencias a fotografías de otro equipo, esas imágenes no estarán disponibles hasta trasladar los archivos originales al nuevo directorio. Un registro sin fotografía no necesita ningún archivo.

### Cómo funciona el directorio de imágenes

La variable `IMAGENES_DIR` es **obligatoria**. En IntelliJ IDEA se configura en la ejecución de `GestorIncidenciasApplication`, junto con `DB_PASSWORD`. Si falta, el arranque avisará del valor de configuración ausente. El directorio se crea automáticamente si hay permisos.

Los nombres almacenados siguen el patrón `UUID.jpg` o `UUID.png`. La validación del contenido se realiza en el servidor antes de copiar el archivo. Los nombres originales recibidos del navegador no se utilizan como rutas.

Si una operación de MySQL falla después de guardar una imagen nueva, se intenta borrar el archivo recién creado. En sustituciones y eliminaciones se actualiza primero MySQL y después se intenta retirar el archivo antiguo; un fallo excepcional al borrar archivos puede necesitar limpieza manual, pues no hay una transacción común entre MySQL y el disco.
