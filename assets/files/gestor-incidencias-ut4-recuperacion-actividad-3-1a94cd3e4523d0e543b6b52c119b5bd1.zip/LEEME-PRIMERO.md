# Recuperación de la Actividad 3 · Gestor de incidencias (UT4)

Esta copia está preparada para comenzar **la Actividad 3B: un panel de seguimiento con DTO y proyecciones**.

- **Quien haya terminado la Actividad 3 debe conservar su proyecto original.**
- Quien no la haya terminado puede abrir `gestor_incidencias/` en IntelliJ IDEA y continuar desde aquí.
- El listado existente incluye filtros por texto, prioridad y estado, método derivado, JPQL, cuatro órdenes y paginación de ocho registros; el CRUD sigue funcionando.
- **No están resueltas** la proyección de interfaz, el DTO, la transformación `Page.map()` ni la ruta de seguimiento.

En `gestor_incidencias/README-RECUPERACION.md` se encuentran los pasos de preparación.

El archivo `datos-prueba-actividad-03.sql` contiene 48 casos de prueba y puede ejecutarse después de iniciar la aplicación y crear la tabla. Si ya existen los mismos registros, el script no los duplica. No borra datos existentes.

**Seguridad:** configurar `DB_PASSWORD` en el entorno de ejecución; no introducir credenciales reales en archivos del proyecto.
