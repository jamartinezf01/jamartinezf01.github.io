# Gestor de incidencias · Recuperación de la Actividad 3 (UT4)

Este proyecto proporciona el **estado que debería tener el gestor al finalizar la Actividad 3**. Sirve como punto de partida para la **Actividad 3B: Un panel de seguimiento (DTO y proyecciones)**.

Si ya has completado tu propio proyecto de la Actividad 3, sigue con él. **No sustituyas tu aplicación ni tu base de datos** por esta copia.

## Qué contiene

- Entidad `Incidencia` con validación, repositorio Spring Data JPA, servicio y controlador MVC.
- Vistas Thymeleaf de listado, alta, detalle y edición; eliminación por POST; CSS.
- Buscador del listado con filtros opcionales `texto`, `prioridad` y `estado`.
- Una consulta derivada utilizada realmente en el servicio cuando se filtra solo por prioridad.
- Una consulta JPQL para combinar los filtros (`AND`).
- Ordenaciones `fecha_desc`, `fecha_asc`, `titulo_asc`, `titulo_desc`.
- Paginación de **8 incidencias** por página, conservando filtros y orden en los enlaces.
- Tratamiento de resultados vacíos y páginas fuera del rango.
- `datos-prueba-actividad-03.sql` (en la raíz del ZIP), con 48 casos de prueba.

## Qué NO contiene

- **Ninguna proyección de interfaz.**
- **Ningún DTO de seguimiento.**
- **Ningún método que transforme la página mediante `Page.map()`.**
- **Ninguna ruta ni plantilla `/incidencias/seguimiento`.**

Esas cuatro partes constituyen el trabajo de la **Actividad 3B**. El proyecto de recuperación NO resuelve la ampliación.

## Puesta en marcha

1. Abre la carpeta `gestor_incidencias` desde IntelliJ IDEA y selecciona **Java 21**. Se usa Spring Boot **4.1.2**.
2. Importa el `pom.xml` como proyecto Maven. El lanzador `mvnw.cmd` usa el script incluido en `.mvn/wrapper` si no tienes Maven disponible.
3. Asegúrate de tener MySQL en `localhost:3306`. El proyecto espera la base de datos `gestor_incidencias` y el usuario `incidencias_app`.
4. Configura la variable de entorno `DB_PASSWORD` en **Run → Edit Configurations** (IntelliJ IDEA). No escribas la contraseña en `application.properties` ni la subas al repositorio.
5. Solo si necesitas crear la base y el usuario desde cero, revisa `preparacion-bd.sql` con un administrador y sustituye el marcador de contraseña. No ejecutes este paso sobre una base ya preparada.
6. Arranca `GestorIncidenciasApplication` y abre `http://localhost:8080/incidencias`.
7. Si todavía no has cargado registros de prueba, ejecuta **una vez** el script `datos-prueba-actividad-03.sql` desde MySQL Workbench, **después** de que Hibernate haya creado `incidencias`. El script es idempotente para sus propios 48 registros y no borra los datos existentes.
8. Comprueba los filtros, la paginación y las operaciones CRUD antes de comenzar la ampliación.

## Pruebas de la Actividad 3 ya preparadas

- `GET /incidencias`: muestra como máximo 8 registros, ordenados por fecha descendente.
- `GET /incidencias?prioridad=ALTA`: filtro derivado de prioridad.
- `GET /incidencias?texto=red&prioridad=ALTA&estado=ABIERTA`: filtros combinados JPQL.
- `GET /incidencias?orden=titulo_asc&pagina=1`: segunda página, ordenada por título.
- `GET /incidencias?pagina=9999`: se muestra la última página existente, si hay resultados.

**Al comenzar la Actividad 3B**, no debes modificar el buscador que ya funciona. Añadirás un panel nuevo para las incidencias pendientes utilizando DTO y proyecciones.
