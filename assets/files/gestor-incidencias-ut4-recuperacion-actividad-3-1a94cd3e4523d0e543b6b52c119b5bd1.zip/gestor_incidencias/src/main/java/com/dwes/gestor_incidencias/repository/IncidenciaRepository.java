package com.dwes.gestor_incidencias.repository;

import com.dwes.gestor_incidencias.model.Incidencia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface IncidenciaRepository extends JpaRepository<Incidencia, Long> {

    // Consulta derivada: se utiliza desde el servicio cuando solo filtramos por prioridad.
    Page<Incidencia> findByPrioridad(String prioridad, Pageable pageable);

    // Consulta JPQL para combinar filtros opcionales.
    @Query("""
            SELECT i FROM Incidencia i
            WHERE (:texto = '' OR LOWER(i.titulo) LIKE LOWER(CONCAT('%', :texto, '%')))
              AND (:prioridad = '' OR i.prioridad = :prioridad)
              AND (:estado = '' OR i.estado = :estado)
            """)
    Page<Incidencia> buscarConFiltros(
            @Param("texto") String texto,
            @Param("prioridad") String prioridad,
            @Param("estado") String estado,
            Pageable pageable);
}
