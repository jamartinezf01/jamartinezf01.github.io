package com.dwes.gestor_incidencias.service;

import com.dwes.gestor_incidencias.model.Incidencia;
import com.dwes.gestor_incidencias.repository.IncidenciaRepository;
import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class IncidenciaService {

    private static final Set<String> PRIORIDADES = Set.of("BAJA", "MEDIA", "ALTA");
    private static final Set<String> ESTADOS = Set.of("ABIERTA", "EN_PROCESO", "RESUELTA");
    private static final int TAMANO_PAGINA = 8;

    private final IncidenciaRepository incidenciaRepository;

    public IncidenciaService(IncidenciaRepository incidenciaRepository) {
        this.incidenciaRepository = incidenciaRepository;
    }

    /** Búsqueda filtrada, ordenada y paginada de la actividad 3. */
    public Page<Incidencia> buscar(String texto, String prioridad, String estado,
                                   String orden, int numeroPagina) {
        String textoSeguro = texto == null ? "" : texto.trim();
        String prioridadSegura = normalizarOpcion(prioridad, PRIORIDADES);
        String estadoSeguro = normalizarOpcion(estado, ESTADOS);
        int indice = Math.max(0, numeroPagina);

        Sort ordenacion = crearOrden(orden);
        Pageable pageable = PageRequest.of(indice, TAMANO_PAGINA, ordenacion);
        Page<Incidencia> resultado = consultar(textoSeguro, prioridadSegura,
                estadoSeguro, pageable);

        // Si se solicita una página excesiva, mostramos la última que exista.
        if (resultado.getTotalPages() > 0 && indice >= resultado.getTotalPages()) {
            pageable = PageRequest.of(resultado.getTotalPages() - 1,
                    TAMANO_PAGINA, ordenacion);
            resultado = consultar(textoSeguro, prioridadSegura, estadoSeguro, pageable);
        }
        return resultado;
    }

    private Page<Incidencia> consultar(String texto, String prioridad, String estado,
                                      Pageable pageable) {
        // Usamos de verdad el método derivado en un caso concreto.
        if (texto.isEmpty() && estado.isEmpty() && !prioridad.isEmpty()) {
            return incidenciaRepository.findByPrioridad(prioridad, pageable);
        }
        return incidenciaRepository.buscarConFiltros(texto, prioridad, estado, pageable);
    }

    private Sort crearOrden(String seleccion) {
        String opcion = seleccion == null ? "fecha_desc" : seleccion;
        return switch (opcion) {
            case "fecha_asc" -> Sort.by("fechaRegistro").ascending()
                    .and(Sort.by("id").ascending());
            case "titulo_asc" -> Sort.by("titulo").ascending()
                    .and(Sort.by("id").ascending());
            case "titulo_desc" -> Sort.by("titulo").descending()
                    .and(Sort.by("id").ascending());
            default -> Sort.by("fechaRegistro").descending()
                    .and(Sort.by("id").descending());
        };
    }

    private String normalizarOpcion(String valor, Set<String> permitidas) {
        if (valor == null) {
            return "";
        }
        String limpio = valor.trim();
        return permitidas.contains(limpio) ? limpio : "";
    }

    public Optional<Incidencia> buscarPorId(Long id) {
        return incidenciaRepository.findById(id);
    }

    public Incidencia registrar(Incidencia datos) {
        verificarPrioridad(datos.getPrioridad());
        Incidencia nueva = new Incidencia();
        nueva.setTitulo(datos.getTitulo());
        nueva.setDescripcion(datos.getDescripcion());
        nueva.setPrioridad(datos.getPrioridad());
        nueva.setEstado("ABIERTA");
        nueva.setFechaRegistro(LocalDate.now());
        return incidenciaRepository.save(nueva);
    }

    public Optional<Incidencia> actualizar(Long id, Incidencia datos) {
        verificarPrioridad(datos.getPrioridad());
        verificarEstado(datos.getEstado());
        return incidenciaRepository.findById(id).map(existente -> {
            existente.setTitulo(datos.getTitulo());
            existente.setDescripcion(datos.getDescripcion());
            existente.setPrioridad(datos.getPrioridad());
            existente.setEstado(datos.getEstado());
            // Conservamos el identificador y la fecha original.
            return incidenciaRepository.save(existente);
        });
    }

    public boolean eliminar(Long id) {
        if (!incidenciaRepository.existsById(id)) {
            return false;
        }
        incidenciaRepository.deleteById(id);
        return true;
    }

    private void verificarPrioridad(String prioridad) {
        if (!PRIORIDADES.contains(prioridad)) {
            throw new IllegalArgumentException("Prioridad no válida");
        }
    }

    private void verificarEstado(String estado) {
        if (!ESTADOS.contains(estado)) {
            throw new IllegalArgumentException("Estado no válido");
        }
    }
}
