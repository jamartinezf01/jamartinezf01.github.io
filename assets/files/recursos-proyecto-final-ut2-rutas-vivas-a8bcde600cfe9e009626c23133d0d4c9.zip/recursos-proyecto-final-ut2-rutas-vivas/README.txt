RUTAS VIVAS - RECURSOS BASE UT2

Este paquete contiene únicamente recursos de interfaz.
No contiene controladores, clases Java ni una solución Spring Boot.

- html-base/: maquetas HTML estáticas de referencia.
- css/: hoja de estilos.
- img/: imágenes SVG utilizadas por las maquetas.

El alumnado deberá integrar y adaptar estos recursos dentro de su propio proyecto Spring Boot + Thymeleaf.
