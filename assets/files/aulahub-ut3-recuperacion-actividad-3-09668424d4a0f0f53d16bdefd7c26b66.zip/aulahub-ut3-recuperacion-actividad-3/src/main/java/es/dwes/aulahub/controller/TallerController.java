package es.dwes.aulahub.controller;

import es.dwes.aulahub.model.InscripcionForm;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class TallerController {

    @GetMapping("/talleres")
    public String mostrarTalleres(Model model) {
        model.addAttribute("inscripcion", new InscripcionForm());
        prepararDatosFormulario(model);
        return "talleres";
    }

    @GetMapping("/talleres/buscar")
    public String buscarTaller(@RequestParam String texto, Model model) {
        model.addAttribute("texto", texto);
        return "resultado-busqueda";
    }

    @PostMapping("/talleres/inscripcion")
    public String procesarInscripcion(
            @Valid @ModelAttribute("inscripcion") InscripcionForm inscripcion,
            BindingResult resultado,
            Model model) {

        if (resultado.hasErrors()) {
            prepararDatosFormulario(model);
            return "talleres";
        }

        return "resultado-inscripcion";
    }

    private void prepararDatosFormulario(Model model) {
        model.addAttribute("talleresDisponibles", List.of(
                "Desarrollo web con Spring Boot",
                "Videojuegos sencillos con Java",
                "Introducción a la ciberseguridad",
                "Interfaces web claras y accesibles"
        ));
    }
}
