# AulaHub · Recuperación de la Actividad 3

Este proyecto contiene el estado mínimo esperado al finalizar la Actividad 3 de la UT3.

Incluye binding con `InscripcionForm`, Jakarta Validation, `@Valid`, `BindingResult`, conservación de valores, recarga de `talleresDisponibles`, `th:errors` y `th:errorclass`.

No incluye todavía redirecciones, `RedirectAttributes`, flash attributes ni el patrón Post/Redirect/Get.
