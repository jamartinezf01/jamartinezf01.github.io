package es.dwes.aulahub.controller;

import es.dwes.aulahub.model.InscripcionForm;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.LinkedHashMap;
import java.util.Map;

@Controller
public class TallerController {

    private void cargarTalleres(Model model) {
        Map<String, String> talleres = new LinkedHashMap<>();
        talleres.put("SPRING", "Desarrollo web con Spring Boot");
        talleres.put("JAVA", "Videojuegos sencillos con Java");
        talleres.put("CIBER", "Introducción a la ciberseguridad");
        talleres.put("WEB", "Interfaces web claras y accesibles");

        model.addAttribute("talleresDisponibles", talleres);
    }

    @GetMapping({"/", "/talleres"})
    public String mostrarTalleres(Model model) {
        cargarTalleres(model);
        model.addAttribute("inscripcion", new InscripcionForm());
        return "talleres";
    }

    @GetMapping("/talleres/buscar")
    public String buscarTalleres(@RequestParam String texto, Model model) {
        model.addAttribute("texto", texto);
        return "resultado-busqueda";
    }

    @PostMapping("/talleres/inscripcion")
    public String inscripcionTalleres(
            @ModelAttribute("inscripcion") InscripcionForm inscripcion) {

        return "resultado-inscripcion";
    }
}
