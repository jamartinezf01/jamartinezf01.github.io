/**
 * Misión 7: Preferencias de la Granja (PLANTILLA ALUMNO)
 * 
 * Sigue los pasos de la Misión para completar este script.
 */

// 1️⃣ REFERENCIAS AL DOM
const btnTema = document.getElementById("btn-tema")
const inputNombre = document.getElementById("nombre-granja")
const btnGuardarNombre = document.getElementById("btn-guardar-nombre")
const displayNombre = document.getElementById("display-nombre")
const msgNombre = document.getElementById("msg-nombre")

const formTarea = document.getElementById("form-tarea")
const inputTarea = document.getElementById("nueva-tarea")
const displayTarea = document.getElementById("display-tarea")

const btnBorrarTodo = document.getElementById("btn-borrar-todo")
const html = document.documentElement // Para cambiar data-tema


// 2️⃣ CARGA INICIAL (Al abrir la página)
// Aquí deberás leer localStorage y sessionStorage para restaurar el estado inicial.


// 3️⃣ CAMBIO DE TEMA (localStorage)
// Escucha el click en btnTema, cambia el data-tema y guárdalo en localStorage.


// 4️⃣ GUARDAR NOMBRE (localStorage)
// Escucha el click en btnGuardarNombre, valida el input, guárdalo y actualiza la vista.


// 5️⃣ GUARDAR TAREA (sessionStorage)
// Escucha el submit de formTarea, previene recarga, valida, guárdala y actualiza la vista.


// 6️⃣ BORRAR TODO (Cerrar Granja)
// Escucha el click de btnBorrarTodo, limpia storage y recarga la página.


// --- FUNCIONES DE AYUDA (Puedes usarlas o crear las tuyas) ---

// Muestra el check de confirmación un par de segundos
function mostrarExito() {
    msgNombre.classList.add("visible")
    setTimeout(() => {
        msgNombre.classList.remove("visible")
    }, 2000)
}
