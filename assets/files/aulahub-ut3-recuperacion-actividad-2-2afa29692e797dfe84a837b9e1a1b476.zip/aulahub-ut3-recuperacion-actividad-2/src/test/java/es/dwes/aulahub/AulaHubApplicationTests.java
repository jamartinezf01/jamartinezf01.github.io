package es.dwes.aulahub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AulaHubApplicationTests {

    @Test
    void contextLoads() {
    }
}
