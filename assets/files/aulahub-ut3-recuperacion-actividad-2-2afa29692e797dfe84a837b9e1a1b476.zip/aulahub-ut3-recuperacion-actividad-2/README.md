# AulaHub · Recuperación de la Actividad 2

Este proyecto contiene el estado mínimo esperado al finalizar la **Actividad 2. Binding con objetos Java** de la UT3.

Incluye:

- buscador mediante GET y `@RequestParam`;
- clase `InscripcionForm` con `nombre`, `email`, `taller` y `edad`;
- preparación de `inscripcion` y `talleresDisponibles` mediante `Model`;
- formulario Thymeleaf con `th:object` y `th:field`;
- `<select>` generado desde el servidor con `th:each`;
- recepción del formulario mediante `@ModelAttribute`;
- vista de resultado que accede a las propiedades de `inscripcion`.

No incluye todavía Jakarta Validation, `@Valid`, `BindingResult`, `th:errors`, redirecciones ni flash attributes.
