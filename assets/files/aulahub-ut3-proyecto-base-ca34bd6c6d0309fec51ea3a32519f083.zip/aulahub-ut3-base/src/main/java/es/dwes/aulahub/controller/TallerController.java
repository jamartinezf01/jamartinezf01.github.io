package es.dwes.aulahub.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TallerController {

    @GetMapping({"/", "/talleres"})
    public String mostrarTalleres() {
        return "talleres";
    }
}
