# AulaHub · Proyecto base UT3

Proyecto inicial para las actividades de **Formularios y validación** de DWES.

## Requisitos

- Java 21.
- IntelliJ IDEA o cualquier IDE compatible con Maven.

## Ejecutar

Desde IntelliJ IDEA puedes ejecutar `AulaHubApplication`.

También puedes utilizar el wrapper incluido:

```bash
.\mvnw.cmd spring-boot:run
```

La aplicación parte de:

```text
http://localhost:8080/talleres
```

## Qué está preparado

- Proyecto Spring Boot con Spring Web y Thymeleaf.
- Página principal de AulaHub.
- Diseño responsive y recursos visuales.
- Plantillas de resultado con zonas preparadas para las actividades.

## Qué NO está resuelto

Los formularios de búsqueda e inscripción, sus rutas de procesamiento y la recepción de datos forman parte del trabajo de la UT3.

La dependencia de Jakarta Validation tampoco está incluida todavía: se añadirá cuando corresponda en la unidad.
