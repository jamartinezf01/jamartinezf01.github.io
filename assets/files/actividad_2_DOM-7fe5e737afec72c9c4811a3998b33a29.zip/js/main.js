// Escribe aquí tu código para completar las 15 misiones de la granja

// Ejercicio 1
const cofre = document.querySelector(".imagen-cofre");

if (cofre) {
    cofre.addEventListener("click", () => {
        const monedas = document.querySelector("#oro");
        let total = Number(monedas.textContent) + 100;
        monedas.textContent = total;
    });
}

// Ejercicio 2
const herramientas = document.querySelectorAll(".hueco");

herramientas.forEach(herramienta => {
    herramienta.addEventListener("mouseover", () => {
        herramienta.style.cursor = "pointer";
        herramienta.classList.add("activo");
    });

    herramienta.addEventListener("mouseout", () => {
        herramienta.classList.remove("activo");
    });
});

// Ejercicio 3
