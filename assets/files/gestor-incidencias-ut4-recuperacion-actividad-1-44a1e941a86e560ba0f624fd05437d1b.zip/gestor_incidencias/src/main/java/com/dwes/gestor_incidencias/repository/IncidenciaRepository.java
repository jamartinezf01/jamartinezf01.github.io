package com.dwes.gestor_incidencias.repository;

import com.dwes.gestor_incidencias.model.Incidencia;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IncidenciaRepository extends JpaRepository<Incidencia, Long> {
}
