package com.dwes.gestor_incidencias.controller;

import com.dwes.gestor_incidencias.model.Incidencia;
import com.dwes.gestor_incidencias.repository.IncidenciaRepository;
import java.time.LocalDate;
import java.util.Set;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Controlador de partida: usa el repositorio directamente, como en la actividad 1.
 * En la actividad 2 debe sustituirse por una capa IncidenciaService.
 */
@Controller
public class IncidenciaController {

    private static final Set<String> PRIORIDADES = Set.of("BAJA", "MEDIA", "ALTA");
    private final IncidenciaRepository incidenciaRepository;

    public IncidenciaController(IncidenciaRepository incidenciaRepository) {
        this.incidenciaRepository = incidenciaRepository;
    }

    @GetMapping("/")
    public String inicio() {
        return "redirect:/incidencias";
    }

    @GetMapping("/incidencias")
    public String listarIncidencias(Model model) {
        model.addAttribute("incidencias", incidenciaRepository.findAll());
        return "incidencias";
    }

    @GetMapping("/incidencias/nueva")
    public String mostrarFormulario(Model model) {
        model.addAttribute("incidencia", new Incidencia());
        return "nueva-incidencia";
    }

    @PostMapping("/incidencias/nueva")
    public String guardarIncidencia(@ModelAttribute Incidencia incidencia, Model model) {
        // Comprobación básica de la actividad 1; en la actividad 2 toca Jakarta Validation.
        if (incidencia.getTitulo() == null || incidencia.getTitulo().isBlank()
                || incidencia.getTitulo().length() > 100
                || incidencia.getDescripcion() == null || incidencia.getDescripcion().isBlank()
                || incidencia.getDescripcion().length() > 500
                || !PRIORIDADES.contains(incidencia.getPrioridad())) {
            model.addAttribute("error", "Revisa el título, la descripción y la prioridad.");
            return "nueva-incidencia";
        }

        // Ninguno de estos datos debe ser decidido por el formulario.
        incidencia.setId(null);
        incidencia.setEstado("ABIERTA");
        incidencia.setFechaRegistro(LocalDate.now());
        incidenciaRepository.save(incidencia);
        return "redirect:/incidencias";
    }
}
