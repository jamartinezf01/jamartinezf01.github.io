# Lanzador didáctico sencillo: descarga Maven 3.9.11 si no está disponible.
# Las dependencias del proyecto están en pom.xml; no contiene credenciales.
$ErrorActionPreference = 'Stop'
$version = '3.9.11'
$install = Join-Path $env:USERPROFILE ".m2\wrapper\apache-maven-$version"
$mvn = Join-Path $install "apache-maven-$version\bin\mvn.cmd"
if (-not (Test-Path $mvn)) {
    $archive = Join-Path $env:TEMP "apache-maven-$version-bin.zip"
    $url = "https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/$version/apache-maven-$version-bin.zip"
    Write-Host "Descargando Maven $version desde Maven Central..."
    New-Item -ItemType Directory -Force -Path $install | Out-Null
    Invoke-WebRequest -Uri $url -OutFile $archive
    Expand-Archive -Path $archive -DestinationPath $install -Force
    Remove-Item $archive -ErrorAction SilentlyContinue
}
& $mvn @args
exit $LASTEXITCODE
