# Proyecto de recuperación · Actividad 2 · DWES UT4

Este proyecto reproduce **el resultado mínimo de la actividad 1**. Está destinado únicamente a quienes
no pudieron terminar el gestor de incidencias. Si tu proyecto de la actividad 1 funciona, continúa con él.

## ¿Qué funciona ya?

- Entidad `Incidencia` y tabla `incidencias` gestionada por JPA.
- `IncidenciaRepository`, basado en `JpaRepository`.
- Controlador con `GET /incidencias`, `GET /incidencias/nueva` y `POST /incidencias/nueva`.
- Listado y alta con Thymeleaf, y CSS incluido.
- Comprobaciones básicas para evitar datos vacíos y prioridades no válidas (no son todavía la validación de la actividad 2).

## ¿Qué no está hecho?

- `IncidenciaService`: ahora el controlador todavía utiliza el repositorio directamente.
- Vista de detalle, edición, eliminación y sus rutas.
- Validación de formularios mediante Jakarta Validation, `@Valid`, `BindingResult` y mensajes por campo.
- Tratamiento de identificadores inexistentes.
- Filtros, consultas personalizadas y paginación (reservados para la actividad 3).

## Cómo utilizarlo

1. Descomprime el ZIP y abre **la carpeta `gestor_incidencias`** desde IntelliJ IDEA gratuito.
2. Selecciona **JDK 21** y deja que Maven importe las dependencias del `pom.xml`.
3. Comprueba que tu servidor MySQL está iniciado en `localhost:3306`.
4. Si todavía no preparaste la base de datos, abre `preparacion-bd.sql` con una **cuenta administradora** de MySQL. Cambia la contraseña de ejemplo antes de ejecutarlo. Si ya existe la base de datos de la actividad 1, **no la borres ni la sustituyas**.
5. Configura la variable de entorno `DB_PASSWORD` en IntelliJ IDEA con la contraseña real de `incidencias_app`.
6. Ejecuta `GestorIncidenciasApplication`. Comprueba `http://localhost:8080/incidencias` y `http://localhost:8080/incidencias/nueva`.
7. Registra una incidencia y verifica que aparece en el listado y en MySQL.
8. Empieza la **actividad 2** a partir de este punto y modifica el proyecto; no entregues el ZIP de recuperación sin resolver las ampliaciones.

## Dependencias Maven incluidas

El proyecto utiliza Spring Boot **4.1.2** y **Java 21**.

| Dependencia | Función |
| --- | --- |
| `spring-boot-starter-webmvc` | Controladores Spring MVC y servidor web. |
| `spring-boot-starter-thymeleaf` | Vistas Thymeleaf. |
| `spring-boot-starter-data-jpa` | JPA, Hibernate y repositorios. |
| `spring-boot-starter-validation` | Jakarta Validation necesaria en la actividad 2. |
| `mysql-connector-j` | Conexión MySQL (runtime). |
| `spring-boot-starter-test` | Dependencias de pruebas (test). |

No necesitas instalar Maven por separado si utilizas el soporte Maven de IntelliJ IDEA.
En Windows también puedes utilizar `mvnw.cmd`, que descarga una distribución Maven en tu equipo
cuando no está disponible. **La primera ejecución requiere conexión a Internet.**

## Preparación de la entrega

Sigue el enunciado de la actividad 2. Entrega **el proyecto que hayas completado**,
con el nombre `apellido-nombre-UT4-2.zip`, sin contraseñas ni carpeta `target`.
No es necesario enviar los datos MySQL.
