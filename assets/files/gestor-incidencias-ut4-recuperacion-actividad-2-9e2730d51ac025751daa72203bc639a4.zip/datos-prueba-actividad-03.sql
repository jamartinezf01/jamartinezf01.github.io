-- Actividad 3 · Datos de prueba del gestor de incidencias
-- Ejecutar SOLO después de crear la tabla con JPA (actividad 1 / recuperación).
-- Conectar a gestor_incidencias con incidencias_app o usuario autorizado.
-- No borra ni modifica incidencias existentes.
-- Cada fila se inserta una sola vez: identificamos el caso por título y fecha.
USE gestor_incidencias;

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de red - aula 01', 'La conexión de red deja de funcionar de forma intermitente. Incidencia registrada para el espacio 01.', 'ALTA', 'ABIERTA', '2026-09-01'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de red - aula 01' AND fecha_registro = '2026-09-01'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Avería de impresora - aula 02', 'La impresora no responde y bloquea la cola de impresión. Incidencia registrada para el espacio 02.', 'MEDIA', 'ABIERTA', '2026-09-02'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Avería de impresora - aula 02' AND fecha_registro = '2026-09-02'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Problema con proyector - aula 03', 'El proyector no muestra la imagen del ordenador. Incidencia registrada para el espacio 03.', 'BAJA', 'ABIERTA', '2026-09-03'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Problema con proyector - aula 03' AND fecha_registro = '2026-09-03'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Error al instalar software - aula 04', 'El programa solicitado genera un error de instalación. Incidencia registrada para el espacio 04.', 'ALTA', 'EN_PROCESO', '2026-09-04'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Error al instalar software - aula 04' AND fecha_registro = '2026-09-04'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Pantalla sin imagen - aula 05', 'El monitor permanece apagado durante el arranque. Incidencia registrada para el espacio 05.', 'MEDIA', 'EN_PROCESO', '2026-09-05'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Pantalla sin imagen - aula 05' AND fecha_registro = '2026-09-05'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de inicio de sesión - aula 06', 'El acceso con las credenciales habituales no funciona. Incidencia registrada para el espacio 06.', 'BAJA', 'EN_PROCESO', '2026-09-06'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de inicio de sesión - aula 06' AND fecha_registro = '2026-09-06'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Conexión wifi inestable - aula 07', 'La conexión inalámbrica presenta cortes frecuentes. Incidencia registrada para el espacio 07.', 'ALTA', 'RESUELTA', '2026-09-07'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Conexión wifi inestable - aula 07' AND fecha_registro = '2026-09-07'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Ratón sin respuesta - aula 08', 'El dispositivo de entrada no responde correctamente. Incidencia registrada para el espacio 08.', 'MEDIA', 'RESUELTA', '2026-09-08'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Ratón sin respuesta - aula 08' AND fecha_registro = '2026-09-08'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de red - aula 09', 'La conexión de red deja de funcionar de forma intermitente. Incidencia registrada para el espacio 09.', 'BAJA', 'RESUELTA', '2026-09-09'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de red - aula 09' AND fecha_registro = '2026-09-09'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Avería de impresora - aula 10', 'La impresora no responde y bloquea la cola de impresión. Incidencia registrada para el espacio 10.', 'ALTA', 'ABIERTA', '2026-09-10'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Avería de impresora - aula 10' AND fecha_registro = '2026-09-10'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Problema con proyector - aula 11', 'El proyector no muestra la imagen del ordenador. Incidencia registrada para el espacio 11.', 'MEDIA', 'ABIERTA', '2026-09-11'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Problema con proyector - aula 11' AND fecha_registro = '2026-09-11'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Error al instalar software - aula 12', 'El programa solicitado genera un error de instalación. Incidencia registrada para el espacio 12.', 'BAJA', 'ABIERTA', '2026-09-12'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Error al instalar software - aula 12' AND fecha_registro = '2026-09-12'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Pantalla sin imagen - aula 13', 'El monitor permanece apagado durante el arranque. Incidencia registrada para el espacio 13.', 'ALTA', 'EN_PROCESO', '2026-09-13'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Pantalla sin imagen - aula 13' AND fecha_registro = '2026-09-13'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de inicio de sesión - aula 14', 'El acceso con las credenciales habituales no funciona. Incidencia registrada para el espacio 14.', 'MEDIA', 'EN_PROCESO', '2026-09-14'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de inicio de sesión - aula 14' AND fecha_registro = '2026-09-14'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Conexión wifi inestable - aula 15', 'La conexión inalámbrica presenta cortes frecuentes. Incidencia registrada para el espacio 15.', 'BAJA', 'EN_PROCESO', '2026-09-15'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Conexión wifi inestable - aula 15' AND fecha_registro = '2026-09-15'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Ratón sin respuesta - aula 16', 'El dispositivo de entrada no responde correctamente. Incidencia registrada para el espacio 16.', 'ALTA', 'RESUELTA', '2026-09-16'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Ratón sin respuesta - aula 16' AND fecha_registro = '2026-09-16'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de red - aula 17', 'La conexión de red deja de funcionar de forma intermitente. Incidencia registrada para el espacio 17.', 'MEDIA', 'RESUELTA', '2026-09-17'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de red - aula 17' AND fecha_registro = '2026-09-17'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Avería de impresora - aula 18', 'La impresora no responde y bloquea la cola de impresión. Incidencia registrada para el espacio 18.', 'BAJA', 'RESUELTA', '2026-09-18'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Avería de impresora - aula 18' AND fecha_registro = '2026-09-18'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Problema con proyector - aula 19', 'El proyector no muestra la imagen del ordenador. Incidencia registrada para el espacio 19.', 'ALTA', 'ABIERTA', '2026-09-19'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Problema con proyector - aula 19' AND fecha_registro = '2026-09-19'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Error al instalar software - aula 20', 'El programa solicitado genera un error de instalación. Incidencia registrada para el espacio 20.', 'MEDIA', 'ABIERTA', '2026-09-20'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Error al instalar software - aula 20' AND fecha_registro = '2026-09-20'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Pantalla sin imagen - aula 21', 'El monitor permanece apagado durante el arranque. Incidencia registrada para el espacio 21.', 'BAJA', 'ABIERTA', '2026-09-21'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Pantalla sin imagen - aula 21' AND fecha_registro = '2026-09-21'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de inicio de sesión - aula 22', 'El acceso con las credenciales habituales no funciona. Incidencia registrada para el espacio 22.', 'ALTA', 'EN_PROCESO', '2026-09-22'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de inicio de sesión - aula 22' AND fecha_registro = '2026-09-22'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Conexión wifi inestable - aula 23', 'La conexión inalámbrica presenta cortes frecuentes. Incidencia registrada para el espacio 23.', 'MEDIA', 'EN_PROCESO', '2026-09-23'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Conexión wifi inestable - aula 23' AND fecha_registro = '2026-09-23'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Ratón sin respuesta - aula 24', 'El dispositivo de entrada no responde correctamente. Incidencia registrada para el espacio 24.', 'BAJA', 'EN_PROCESO', '2026-09-24'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Ratón sin respuesta - aula 24' AND fecha_registro = '2026-09-24'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de red - aula 25', 'La conexión de red deja de funcionar de forma intermitente. Incidencia registrada para el espacio 25.', 'ALTA', 'RESUELTA', '2026-09-25'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de red - aula 25' AND fecha_registro = '2026-09-25'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Avería de impresora - aula 26', 'La impresora no responde y bloquea la cola de impresión. Incidencia registrada para el espacio 26.', 'MEDIA', 'RESUELTA', '2026-09-26'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Avería de impresora - aula 26' AND fecha_registro = '2026-09-26'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Problema con proyector - aula 27', 'El proyector no muestra la imagen del ordenador. Incidencia registrada para el espacio 27.', 'BAJA', 'RESUELTA', '2026-09-27'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Problema con proyector - aula 27' AND fecha_registro = '2026-09-27'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Error al instalar software - aula 28', 'El programa solicitado genera un error de instalación. Incidencia registrada para el espacio 28.', 'ALTA', 'ABIERTA', '2026-09-28'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Error al instalar software - aula 28' AND fecha_registro = '2026-09-28'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Pantalla sin imagen - aula 29', 'El monitor permanece apagado durante el arranque. Incidencia registrada para el espacio 29.', 'MEDIA', 'ABIERTA', '2026-09-29'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Pantalla sin imagen - aula 29' AND fecha_registro = '2026-09-29'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de inicio de sesión - aula 30', 'El acceso con las credenciales habituales no funciona. Incidencia registrada para el espacio 30.', 'BAJA', 'ABIERTA', '2026-09-30'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de inicio de sesión - aula 30' AND fecha_registro = '2026-09-30'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Conexión wifi inestable - aula 31', 'La conexión inalámbrica presenta cortes frecuentes. Incidencia registrada para el espacio 31.', 'ALTA', 'EN_PROCESO', '2026-10-01'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Conexión wifi inestable - aula 31' AND fecha_registro = '2026-10-01'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Ratón sin respuesta - aula 32', 'El dispositivo de entrada no responde correctamente. Incidencia registrada para el espacio 32.', 'MEDIA', 'EN_PROCESO', '2026-10-02'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Ratón sin respuesta - aula 32' AND fecha_registro = '2026-10-02'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de red - aula 33', 'La conexión de red deja de funcionar de forma intermitente. Incidencia registrada para el espacio 33.', 'BAJA', 'EN_PROCESO', '2026-10-03'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de red - aula 33' AND fecha_registro = '2026-10-03'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Avería de impresora - aula 34', 'La impresora no responde y bloquea la cola de impresión. Incidencia registrada para el espacio 34.', 'ALTA', 'RESUELTA', '2026-10-04'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Avería de impresora - aula 34' AND fecha_registro = '2026-10-04'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Problema con proyector - aula 35', 'El proyector no muestra la imagen del ordenador. Incidencia registrada para el espacio 35.', 'MEDIA', 'RESUELTA', '2026-10-05'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Problema con proyector - aula 35' AND fecha_registro = '2026-10-05'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Error al instalar software - aula 36', 'El programa solicitado genera un error de instalación. Incidencia registrada para el espacio 36.', 'BAJA', 'RESUELTA', '2026-10-06'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Error al instalar software - aula 36' AND fecha_registro = '2026-10-06'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Pantalla sin imagen - aula 37', 'El monitor permanece apagado durante el arranque. Incidencia registrada para el espacio 37.', 'ALTA', 'ABIERTA', '2026-10-07'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Pantalla sin imagen - aula 37' AND fecha_registro = '2026-10-07'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de inicio de sesión - aula 38', 'El acceso con las credenciales habituales no funciona. Incidencia registrada para el espacio 38.', 'MEDIA', 'ABIERTA', '2026-10-08'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de inicio de sesión - aula 38' AND fecha_registro = '2026-10-08'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Conexión wifi inestable - aula 39', 'La conexión inalámbrica presenta cortes frecuentes. Incidencia registrada para el espacio 39.', 'BAJA', 'ABIERTA', '2026-10-09'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Conexión wifi inestable - aula 39' AND fecha_registro = '2026-10-09'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Ratón sin respuesta - aula 40', 'El dispositivo de entrada no responde correctamente. Incidencia registrada para el espacio 40.', 'ALTA', 'EN_PROCESO', '2026-10-10'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Ratón sin respuesta - aula 40' AND fecha_registro = '2026-10-10'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de red - aula 41', 'La conexión de red deja de funcionar de forma intermitente. Incidencia registrada para el espacio 41.', 'MEDIA', 'EN_PROCESO', '2026-10-11'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de red - aula 41' AND fecha_registro = '2026-10-11'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Avería de impresora - aula 42', 'La impresora no responde y bloquea la cola de impresión. Incidencia registrada para el espacio 42.', 'BAJA', 'EN_PROCESO', '2026-10-12'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Avería de impresora - aula 42' AND fecha_registro = '2026-10-12'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Problema con proyector - aula 43', 'El proyector no muestra la imagen del ordenador. Incidencia registrada para el espacio 43.', 'ALTA', 'RESUELTA', '2026-10-13'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Problema con proyector - aula 43' AND fecha_registro = '2026-10-13'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Error al instalar software - aula 44', 'El programa solicitado genera un error de instalación. Incidencia registrada para el espacio 44.', 'MEDIA', 'RESUELTA', '2026-10-14'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Error al instalar software - aula 44' AND fecha_registro = '2026-10-14'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Pantalla sin imagen - aula 45', 'El monitor permanece apagado durante el arranque. Incidencia registrada para el espacio 45.', 'BAJA', 'RESUELTA', '2026-10-15'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Pantalla sin imagen - aula 45' AND fecha_registro = '2026-10-15'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Fallo de inicio de sesión - aula 46', 'El acceso con las credenciales habituales no funciona. Incidencia registrada para el espacio 46.', 'ALTA', 'ABIERTA', '2026-10-16'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Fallo de inicio de sesión - aula 46' AND fecha_registro = '2026-10-16'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Conexión wifi inestable - aula 47', 'La conexión inalámbrica presenta cortes frecuentes. Incidencia registrada para el espacio 47.', 'MEDIA', 'ABIERTA', '2026-10-17'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Conexión wifi inestable - aula 47' AND fecha_registro = '2026-10-17'
);

INSERT INTO incidencias (titulo, descripcion, prioridad, estado, fecha_registro)
SELECT 'Ratón sin respuesta - aula 48', 'El dispositivo de entrada no responde correctamente. Incidencia registrada para el espacio 48.', 'BAJA', 'ABIERTA', '2026-10-18'
WHERE NOT EXISTS (
    SELECT 1 FROM incidencias WHERE titulo = 'Ratón sin respuesta - aula 48' AND fecha_registro = '2026-10-18'
);

-- Resumen (incluye también las incidencias que ya tuvieseis):
SELECT COUNT(*) AS total_incidencias FROM incidencias;
SELECT prioridad, estado, COUNT(*) AS cantidad
FROM incidencias GROUP BY prioridad, estado ORDER BY prioridad, estado;
