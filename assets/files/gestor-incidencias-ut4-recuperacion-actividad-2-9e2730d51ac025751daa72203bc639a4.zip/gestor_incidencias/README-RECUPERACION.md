# Gestor de incidencias · Recuperación para la actividad 3 (UT4)

Este proyecto contiene la **solución de partida esperada al terminar la actividad 2**, para quienes no hayan conseguido completar ese trabajo. Si tu propio gestor funciona, **continúa con él** y no reemplaces tus datos ni código.

## Funcionalidades que ya están implementadas

- `Incidencia` con mapeo JPA y anotaciones de validación.
- `IncidenciaRepository` y **capa `IncidenciaService`**.
- Listado, alta, ficha de detalle, edición y eliminación con Spring MVC y Thymeleaf.
- Verificación de restricciones y mensajes de error en los formularios.
- Gestión de identificadores inexistentes.
- CSS y conexión MySQL mediante la variable `DB_PASSWORD`.

## Qué NO está implementado (es el trabajo de la actividad 3)

- Filtro de título, prioridad y estado, individuales o combinados.
- Métodos derivados y consultas JPQL de búsqueda.
- Selección de orden, ordenación múltiple y paginación.
- Navegación entre páginas conservando los filtros.

## Puesta en marcha

1. Abre la carpeta `gestor_incidencias` desde IntelliJ IDEA gratuito y usa **Java 21**.
2. Importa las dependencias Maven del `pom.xml` (Spring Boot **4.1.2**).
3. Inicia MySQL en `localhost:3306` y configura la variable `DB_PASSWORD` con la contraseña de `incidencias_app`.
4. Si todavía no existe la base de datos, utiliza `preparacion-bd.sql` **con una cuenta administradora** y sustituye la contraseña de ejemplo. No ejecutes el script si ya tienes la base preparada.
5. Ejecuta `GestorIncidenciasApplication` y comprueba `http://localhost:8080/incidencias`.
6. Antes de trabajar en la actividad 3, verifica que puedes dar de alta, editar, consultar y eliminar una incidencia.
7. Utiliza el archivo **`datos-prueba-actividad-03.sql`** del ZIP para cargar casos de prueba; no borra registros existentes y puedes ejecutarlo de nuevo sin duplicar esos casos.

**La actividad 3 debe desarrollarse sobre este proyecto** si utilizas la recuperación. Entregar la recuperación sin modificar no cumple los requisitos.

## Dependencias incluidas

- `spring-boot-starter-webmvc`.
- `spring-boot-starter-thymeleaf`.
- `spring-boot-starter-data-jpa`.
- `spring-boot-starter-validation`.
- `mysql-connector-j`.
- `spring-boot-starter-test` (ámbito test).

El `pom.xml` conserva todas las dependencias necesarias para filtros, JPQL, ordenación y paginación: Spring Data JPA ya proporciona las interfaces `Page`, `Pageable`, `PageRequest` y `Sort`, por lo que **no es necesario añadir otra dependencia**.

### Nota sobre Maven

Se incluye el mismo lanzador `mvnw.cmd` utilizado en la recuperación anterior. En Windows descarga Maven si no lo encuentra (requiere conexión a Internet la primera vez). También puedes utilizar la ventana de Maven de IntelliJ IDEA.
