package com.dwes.gestor_incidencias.controller;

import com.dwes.gestor_incidencias.model.Incidencia;
import com.dwes.gestor_incidencias.service.IncidenciaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class IncidenciaController {

    private final IncidenciaService incidenciaService;

    public IncidenciaController(IncidenciaService incidenciaService) {
        this.incidenciaService = incidenciaService;
    }

    @GetMapping("/incidencias")
    public String listar(Model model) {
        model.addAttribute("incidencias", incidenciaService.listar());
        return "incidencias";
    }

    @GetMapping("/incidencias/nueva")
    public String nueva(Model model) {
        model.addAttribute("incidencia", new Incidencia());
        return "nueva-incidencia";
    }

    @PostMapping("/incidencias/nueva")
    public String guardar(@Valid @ModelAttribute("incidencia") Incidencia incidencia,
                          BindingResult errores) {
        if (errores.hasErrors()) {
            return "nueva-incidencia";
        }
        incidenciaService.registrar(incidencia);
        return "redirect:/incidencias";
    }

    @GetMapping("/incidencias/{id}")
    public String detalle(@PathVariable Long id, Model model) {
        return incidenciaService.buscarPorId(id)
                .map(incidencia -> {
                    model.addAttribute("incidencia", incidencia);
                    return "detalle-incidencia";
                })
                .orElseGet(() -> noEncontrada(id, model));
    }

    @GetMapping("/incidencias/{id}/editar")
    public String editar(@PathVariable Long id, Model model) {
        return incidenciaService.buscarPorId(id)
                .map(incidencia -> {
                    model.addAttribute("incidencia", incidencia);
                    model.addAttribute("idEdicion", id);
                    return "editar-incidencia";
                })
                .orElseGet(() -> noEncontrada(id, model));
    }

    @PostMapping("/incidencias/{id}/editar")
    public String actualizar(@PathVariable Long id,
                             @Valid @ModelAttribute("incidencia") Incidencia incidencia,
                             BindingResult errores, Model model) {
        // Antes de mostrar el formulario, comprobamos que el registro aún existe.
        if (incidenciaService.buscarPorId(id).isEmpty()) {
            return noEncontrada(id, model);
        }
        if (errores.hasErrors()) {
            model.addAttribute("idEdicion", id);
            return "editar-incidencia";
        }
        incidenciaService.actualizar(id, incidencia);
        return "redirect:/incidencias/" + id;
    }

    @PostMapping("/incidencias/{id}/eliminar")
    public String eliminar(@PathVariable Long id, Model model) {
        if (!incidenciaService.eliminar(id)) {
            return noEncontrada(id, model);
        }
        return "redirect:/incidencias";
    }

    private String noEncontrada(Long id, Model model) {
        model.addAttribute("mensaje", "No existe ninguna incidencia con identificador " + id + ".");
        return "incidencia-no-encontrada";
    }
}
