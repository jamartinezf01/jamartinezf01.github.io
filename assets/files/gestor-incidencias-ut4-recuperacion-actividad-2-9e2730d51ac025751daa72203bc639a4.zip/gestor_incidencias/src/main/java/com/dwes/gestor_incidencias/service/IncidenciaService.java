package com.dwes.gestor_incidencias.service;

import com.dwes.gestor_incidencias.model.Incidencia;
import com.dwes.gestor_incidencias.repository.IncidenciaRepository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.stereotype.Service;

@Service
public class IncidenciaService {

    private static final Set<String> PRIORIDADES = Set.of("BAJA", "MEDIA", "ALTA");
    private static final Set<String> ESTADOS = Set.of("ABIERTA", "EN_PROCESO", "RESUELTA");
    private final IncidenciaRepository incidenciaRepository;

    public IncidenciaService(IncidenciaRepository incidenciaRepository) {
        this.incidenciaRepository = incidenciaRepository;
    }

    public List<Incidencia> listar() {
        return incidenciaRepository.findAll();
    }

    public Optional<Incidencia> buscarPorId(Long id) {
        return incidenciaRepository.findById(id);
    }

    public Incidencia registrar(Incidencia datos) {
        verificarPrioridad(datos.getPrioridad());
        Incidencia nueva = new Incidencia();
        nueva.setTitulo(datos.getTitulo());
        nueva.setDescripcion(datos.getDescripcion());
        nueva.setPrioridad(datos.getPrioridad());
        nueva.setEstado("ABIERTA");
        nueva.setFechaRegistro(LocalDate.now());
        return incidenciaRepository.save(nueva);
    }

    public Optional<Incidencia> actualizar(Long id, Incidencia datos) {
        verificarPrioridad(datos.getPrioridad());
        verificarEstado(datos.getEstado());
        return incidenciaRepository.findById(id).map(existente -> {
            existente.setTitulo(datos.getTitulo());
            existente.setDescripcion(datos.getDescripcion());
            existente.setPrioridad(datos.getPrioridad());
            existente.setEstado(datos.getEstado());
            // Conservamos explícitamente el id y la fecha original.
            return incidenciaRepository.save(existente);
        });
    }

    public boolean eliminar(Long id) {
        if (!incidenciaRepository.existsById(id)) {
            return false;
        }
        incidenciaRepository.deleteById(id);
        return true;
    }

    private void verificarPrioridad(String prioridad) {
        if (!PRIORIDADES.contains(prioridad)) {
            throw new IllegalArgumentException("Prioridad no válida");
        }
    }

    private void verificarEstado(String estado) {
        if (!ESTADOS.contains(estado)) {
            throw new IllegalArgumentException("Estado no válido");
        }
    }
}
