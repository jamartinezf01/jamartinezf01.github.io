# Recursos de la Actividad 3 · UT4

Este ZIP contiene dos recursos:

1. `gestor_incidencias/`: proyecto de recuperación opcional con el resultado esperado tras la actividad 2. Si tu proyecto está terminado, **no lo sustituyas**.
2. `datos-prueba-actividad-03.sql`: 48 incidencias de prueba, con título, prioridad, estado y fechas variados, para verificar las consultas y la paginación.

## Orden de trabajo

- Comprueba primero que tu proyecto actual o el de recuperación funciona con MySQL.
- Ejecuta el script desde MySQL Workbench con una cuenta que pueda insertar datos en `gestor_incidencias`.
- El script no borra registros y está preparado para no duplicar **sus 48 filas** al ejecutarlo de nuevo.
- Sigue el enunciado Markdown publicado en Docusaurus. La parte de búsqueda y paginación NO está resuelta en el proyecto.

No se incluyen contraseñas, capturas ni datos personales.
