/**
 * Misión 6: Registro de la Granja (Edición Extendida)
 * 
 * Instrucciones:
 * Completa este archivo siguiendo los 10 puntos de la misión.
 */

// 1. Control de Acceso: Selecciona el formulario
const formulario = null;

// 2. Intercepción de Datos: Evento 'submit' y preventDefault
/*
formulario.addEventListener("submit", (evento) => {
    // Código aquí
});
*/

// 3. Validación en Vivo (Nombre): Evento 'input'

// 4. Vista Previa Dinámica: Nombre, Tipo y Salud

// 5. Contador de Caracteres: Para las observaciones

// 6. El Nombre Prohibido: Filtrar palabras como "malo" o "feo"

// 7. Campos Condicionales: Mostrar producción solo si es Vaca

// 8. Semáforo de Salud: Cambiar color de fondo de la tarjeta

// 9. Reset del Registro: Botón de limpiar todo

// 10. El Gran Registro: Mostrar resumen final en el submit válido
