/**
 * SOLUCIÓN ACTIVIDAD 1 - VIDA EN LA GRANJA
 * Comandos para ejecutar en la consola.
 */

// 1. Bautismo de la Granja
document.getElementById('nombre-granja').textContent = "Granja del Valle";

// 2. Oro Brillante
const dinero = document.getElementById('dinero');
dinero.textContent = "500g";
dinero.style.color = "gold";

// 3. Nuevo Look del Granjero
document.getElementById('avatar').setAttribute('src', 'img/granjero-real.png');

// 4. Sistema de Riego (Clases)
const espacio1 = document.getElementById('espacio-1');
espacio1.classList.add('regado');
espacio1.classList.remove('seco');

// 5. Selección de Herramientas (Toggle)
document.getElementById('slot-vacio').classList.toggle('selected');

// 6. Limpieza sin Desperdicio (Estilo)
document.getElementById('hierba-mala').style.display = 'none';

// 7. Etiquetar Parcelas (Atributos)
document.getElementById('espacio-2').setAttribute('title', 'Listo para sembrar');

// 8. Nivel de Energía
const energia = document.getElementById('energia-actual');
energia.style.width = "15%";
energia.style.backgroundColor = "red";

// 9. Primera Cosecha (QuerySelector)
document.querySelector('.listo-cosecha').style.border = "3px solid white";

// 10. Censo de la Granja (QuerySelectorAll)
const totalParcelas = document.querySelectorAll('.crop-slot').length;
console.log("Total de parcelas: " + totalParcelas);

// 11. Día de Tormenta
const clima = document.getElementById('clima');
clima.textContent = "Tormenta ⛈️";
clima.style.color = "blue";

// 12. El Paso del Calendario
document.getElementById('fecha').textContent = "Invierno 28";

// 13. Espionaje de Cultivos (Atributos)
const infoCultivo = document.querySelector('#espacio-1 img').getAttribute('alt');
console.log("En el espacio 1 hay: " + infoCultivo);

// 14. Modo Nocturno (Estilos)
document.querySelector('.game-container').style.backgroundColor = '#1a1a1a';

// 15. Herramienta de Repuesto (Selección por Índice)
const slots = document.querySelectorAll('.inv-espacio');
slots[5].style.backgroundColor = "lightgray";
