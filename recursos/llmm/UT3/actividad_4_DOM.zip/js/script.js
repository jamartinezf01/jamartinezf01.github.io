/**
 * 🛖 ACTIVIDAD 8: LOGÍSTICA EN EL GRANERO (NAVEGACIÓN)
 *
 * Objetivo: Usa las propiedades de navegación del DOM (parentElement, children, etc.)
 * para completar las misiones del panel lateral.
 */

// --- MISIÓN 1: Identificar al Padre (#btn-padre) ---


// --- MISIÓN 2: Revisar a los Hijos (#btn-hijos) ---


// --- MISIÓN 3: El Primer Comedero (#btn-primer-hijo) ---


// --- MISIÓN 4: El Último Comedero (#btn-ultimo-hijo) ---


// --- MISIÓN 5: Siguiente Establo (#btn-hermano-sig) ---


// --- MISIÓN 6: Establo Anterior (#btn-hermano-ant) ---


// --- MISIÓN 7: Limpiar al Vecino (#btn-limpiar-vecino) ---


// --- MISIÓN 8: Salto al Abuelo (#btn-salto-doble) ---


// --- MISIÓN 9: Nodos vs Elementos (#btn-lista-nodos) ---


// --- MISIÓN 10: Llenar el Hueco Vacío (#btn-llenar-vacio) ---

