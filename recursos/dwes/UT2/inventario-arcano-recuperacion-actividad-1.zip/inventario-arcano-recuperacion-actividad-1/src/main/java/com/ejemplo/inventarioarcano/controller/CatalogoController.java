package com.ejemplo.inventarioarcano.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/catalogo")
public class CatalogoController {

    @GetMapping
    public String catalogo() {
        return "catalogo";
    }

    @GetMapping("/pociones")
    public String pociones() {
        return "pociones";
    }

    @GetMapping("/pergaminos")
    public String pergaminos() {
        return "pergaminos";
    }

    @GetMapping("/artefactos")
    public String artefactos() {
        return "artefactos";
    }

    @GetMapping("/recomendados")
    public String recomendados() {
        return "recomendados";
    }
}
