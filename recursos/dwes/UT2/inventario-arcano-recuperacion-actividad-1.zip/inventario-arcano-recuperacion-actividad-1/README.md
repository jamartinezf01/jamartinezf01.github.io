# Inventario Arcano — recuperación de la Actividad 1

Este proyecto representa el **punto de partida mínimo correcto para comenzar la Actividad 2**.

Úsalo solo si tu proyecto de la Actividad 1 no funciona o si necesitas incorporarte al trabajo desde este punto.

## Qué contiene

- Proyecto Spring Boot con Maven.
- Dependencias Spring Web y Thymeleaf.
- `GeneralController`, `CatalogoController` y `GremioController`.
- Todas las rutas obligatorias de la Actividad 1.
- Plantillas HTML estáticas dentro de `templates`.
- CSS e imágenes en `static`.
- Navegación funcional entre las secciones principales.

## Qué no contiene

No incluye la solución de la Actividad 2: no se han añadido `@PathVariable`, `@RequestParam` ni las nuevas rutas de consulta.

## Puesta en marcha

1. Descomprime el proyecto.
2. Ábrelo como proyecto Maven en IntelliJ IDEA.
3. Espera a que Maven resuelva las dependencias.
4. Ejecuta `InventarioArcanoApplication`.
5. Abre `http://localhost:8080/`.
