# Inventario Arcano — Recuperación para comenzar la Actividad 5

Este proyecto contiene el **estado mínimo esperado al finalizar la Actividad 4**.

Utilízalo únicamente si no has podido completar correctamente las actividades anteriores o si necesitas reincorporarte al proyecto.

Si tu propio Inventario Arcano funciona correctamente, continúa trabajando sobre él.

## Qué incluye

- Todo el estado obligatorio de las actividades 1, 2 y 3.
- Uso de `${...}` para datos de las vistas.
- Uso de `@{...}` para construir URL.
- Enlaces principales mediante `th:href`.
- Recursos estáticos enlazados mediante `th:href` y `th:src`.
- URL con variables de ruta.
- URL con parámetros de consulta.
- Combinación de variable de ruta y query string.
- Enlaces de moneda construidos con `${producto.id}`.
- Enlace de búsqueda construido con datos de `ProductoMagico`.
- Enlaces de ordenación que conservan los criterios de búsqueda.
- Una operación aritmética sencilla en `${...}`.

## Importante

Este proyecto contiene únicamente el **estado obligatorio necesario para comenzar la Actividad 5**.

No incluye las ampliaciones opcionales de las actividades anteriores ni resuelve ningún apartado de la Actividad 5.

Ejecuta `InventarioArcanoApplication` y comprueba que la aplicación arranca antes de continuar.
