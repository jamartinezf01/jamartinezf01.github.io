package com.ejemplo.inventarioarcano.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/gremio")
public class GremioController {

    @GetMapping
    public String gremio() {
        return "gremio";
    }

    @GetMapping("/alquimistas")
    public String alquimistas() {
        return "alquimistas";
    }

    @GetMapping("/encantadores")
    public String encantadores() {
        return "encantadores";
    }
}
