package com.ejemplo.inventarioarcano.model;

public class ProductoMagico {

    private int id;
    private String nombre;
    private String categoria;
    private String rareza;
    private double precio;
    private String descripcion;

    public ProductoMagico(
            int id,
            String nombre,
            String categoria,
            String rareza,
            double precio,
            String descripcion) {

        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.rareza = rareza;
        this.precio = precio;
        this.descripcion = descripcion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getRareza() {
        return rareza;
    }

    public double getPrecio() {
        return precio;
    }

    public String getDescripcion() {
        return descripcion;
    }
}
