package com.ejemplo.inventarioarcano;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventarioArcanoApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventarioArcanoApplication.class, args);
    }
}
