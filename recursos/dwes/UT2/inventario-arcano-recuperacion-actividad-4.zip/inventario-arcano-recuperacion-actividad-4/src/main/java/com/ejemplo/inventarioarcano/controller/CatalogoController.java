package com.ejemplo.inventarioarcano.controller;

import com.ejemplo.inventarioarcano.model.ProductoMagico;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/catalogo")
public class CatalogoController {

    @GetMapping
    public String catalogo() {
        return "catalogo";
    }

    @GetMapping("/pociones")
    public String pociones() {
        return "pociones";
    }

    @GetMapping("/pergaminos")
    public String pergaminos() {
        return "pergaminos";
    }

    @GetMapping("/artefactos")
    public String artefactos() {
        return "artefactos";
    }

    @GetMapping("/recomendados")
    public String recomendados() {
        return "recomendados";
    }

    @GetMapping("/objeto/{id}")
    public String consultarObjeto(
            @PathVariable int id,
            @RequestParam(defaultValue = "oro") String moneda,
            Model model) {

        ProductoMagico producto = obtenerProducto(id);

        model.addAttribute("producto", producto);
        model.addAttribute("moneda", moneda);

        return "detalle-producto";
    }

    @GetMapping("/buscar")
    public String buscar(
            @RequestParam String texto,
            @RequestParam(required = false) String categoria,
            @RequestParam(defaultValue = "todas") String rareza,
            @RequestParam(defaultValue = "250") double precioMax,
            @RequestParam(defaultValue = "nombre") String orden,
            @RequestParam(defaultValue = "false") boolean soloDisponibles,
            Model model) {

        String categoriaMostrada = categoria == null ? "todas" : categoria;

        model.addAttribute("texto", texto);
        model.addAttribute("categoria", categoriaMostrada);
        model.addAttribute("rareza", rareza);
        model.addAttribute("precioMax", precioMax);
        model.addAttribute("orden", orden);
        model.addAttribute("soloDisponibles", soloDisponibles);

        return "resultado-busqueda";
    }

    @GetMapping("/rareza/{rareza}")
    @ResponseBody
    public String consultarPorRareza(
            @PathVariable String rareza,
            @RequestParam(defaultValue = "nombre") String orden,
            @RequestParam(defaultValue = "10") int limite) {

        return "Consulta por rareza\n"
                + "Rareza: " + rareza + "\n"
                + "Orden: " + orden + "\n"
                + "Límite: " + limite;
    }

    private ProductoMagico obtenerProducto(int id) {

        if (id == 1) {
            return new ProductoMagico(
                    1,
                    "Poción de visión nocturna",
                    "Pociones",
                    "Común",
                    35.0,
                    "Permite distinguir formas y caminos en lugares con muy poca luz.");
        }

        if (id == 2) {
            return new ProductoMagico(
                    2,
                    "Pergamino de retorno",
                    "Pergaminos",
                    "Raro",
                    62.5,
                    "Un pergamino sellado utilizado por viajeros para marcar un punto de regreso.");
        }

        if (id == 3) {
            return new ProductoMagico(
                    3,
                    "Brújula astral",
                    "Artefactos",
                    "Épico",
                    145.0,
                    "Una brújula encantada cuya aguja señala el lugar elegido por su portador.");
        }

        return new ProductoMagico(
                id,
                "Objeto sin catalogar",
                "Desconocida",
                "Sin clasificar",
                0.0,
                "El gremio todavía no ha completado la ficha de este objeto.");
    }
}
