package com.ejemplo.inventarioarcano.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class GeneralController {

    @GetMapping("/")
    public String inicio() {
        return "inicio";
    }

    @GetMapping("/tienda")
    public String tienda() {
        return "tienda";
    }

    @GetMapping("/contacto")
    public String contacto() {
        return "contacto";
    }
}
