# Kit de recursos — Inventario Arcano

Este kit acompaña las actividades progresivas de la UT2 de DWES.

## Qué contiene

- `css/inventario-arcano.css`: estilo visual pixel art listo para utilizar.
- `img/`: recursos gráficos en SVG, con fondo transparente y estilo pixel art.
- `html-referencia/`: páginas HTML estáticas de referencia para arrancar la Actividad 1.

## Cómo utilizarlo en Spring Boot

Copia:

- `css/` en `src/main/resources/static/css/`.
- `img/` en `src/main/resources/static/img/`.

Las páginas de `html-referencia/` son prototipos visuales. Puedes usarlas como referencia o copiar su estructura a `src/main/resources/templates/` y adaptarlas a las rutas que se soliciten.
