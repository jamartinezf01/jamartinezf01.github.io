# Inventario Arcano — Recuperación para comenzar la Actividad 4

Este proyecto contiene el **estado mínimo esperado al finalizar la Actividad 3**.

Utilízalo únicamente si no has podido completar correctamente las actividades anteriores o si necesitas reincorporarte al proyecto.

Si tu propio Inventario Arcano funciona correctamente, continúa trabajando sobre él.

## Qué incluye

- Todo el punto de partida obligatorio de las actividades anteriores.
- Clase `ProductoMagico` con constructor y getters.
- Tres productos mágicos diferenciados preparados desde Java.
- Ruta `/catalogo/objeto/{id}` que recibe el identificador y la moneda.
- Uso de `Model` para enviar un objeto `ProductoMagico` y otros atributos a la vista.
- Vista `detalle-producto.html` con `xmlns:th` y `th:text`.
- Acceso desde Thymeleaf a propiedades como `${producto.nombre}`.
- Ruta `/catalogo/buscar` convertida en una vista Thymeleaf.
- Vista `resultado-busqueda.html` con los criterios recibidos por el controlador.
- Enlaces de prueba desde `catalogo.html`.
- Hoja de estilos e imágenes de Inventario Arcano.

## Importante

Este proyecto contiene únicamente el **estado obligatorio necesario para comenzar la Actividad 4**.

No incluye:

- la ampliación opcional de la Actividad 1.
- la ampliación opcional de la Actividad 2.
- la ampliación opcional de la Actividad 3.
- ninguna parte resuelta de la Actividad 4.

Ejecuta `InventarioArcanoApplication` y comprueba que la aplicación arranca antes de continuar.
