package com.ejemplo.inventarioarcano.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/catalogo")
public class CatalogoController {

    @GetMapping
    public String catalogo() {
        return "catalogo";
    }

    @GetMapping("/pociones")
    public String pociones() {
        return "pociones";
    }

    @GetMapping("/pergaminos")
    public String pergaminos() {
        return "pergaminos";
    }

    @GetMapping("/artefactos")
    public String artefactos() {
        return "artefactos";
    }

    @GetMapping("/recomendados")
    public String recomendados() {
        return "recomendados";
    }

    @GetMapping("/objeto/{id}")
    @ResponseBody
    public String consultarObjeto(
            @PathVariable int id,
            @RequestParam(defaultValue = "oro") String moneda,
            @RequestParam(defaultValue = "1") int cantidad,
            @RequestParam(defaultValue = "false") boolean envolver) {

        return "Consulta de objeto arcano\n"
                + "Identificador: " + id + "\n"
                + "Moneda: " + moneda + "\n"
                + "Cantidad: " + cantidad + "\n"
                + "Envolver: " + envolver;
    }

    @GetMapping("/buscar")
    @ResponseBody
    public String buscar(
            @RequestParam String texto,
            @RequestParam(required = false) String categoria,
            @RequestParam(defaultValue = "todas") String rareza,
            @RequestParam(defaultValue = "250") double precioMax,
            @RequestParam(defaultValue = "nombre") String orden,
            @RequestParam(defaultValue = "false") boolean soloDisponibles) {

        String categoriaMostrada = categoria == null ? "todas" : categoria;

        return "Búsqueda en Inventario Arcano\n"
                + "Texto: " + texto + "\n"
                + "Categoría: " + categoriaMostrada + "\n"
                + "Rareza: " + rareza + "\n"
                + "Precio máximo: " + precioMax + "\n"
                + "Orden: " + orden + "\n"
                + "Solo disponibles: " + soloDisponibles;
    }

    @GetMapping("/rareza/{rareza}")
    @ResponseBody
    public String consultarPorRareza(
            @PathVariable String rareza,
            @RequestParam(defaultValue = "nombre") String orden,
            @RequestParam(defaultValue = "10") int limite) {

        return "Consulta por rareza\n"
                + "Rareza: " + rareza + "\n"
                + "Orden: " + orden + "\n"
                + "Límite: " + limite;
    }
}
