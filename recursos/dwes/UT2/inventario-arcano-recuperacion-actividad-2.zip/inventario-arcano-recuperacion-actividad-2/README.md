# Inventario Arcano — Recuperación para comenzar la Actividad 3

Este proyecto contiene el **estado mínimo esperado al finalizar la Actividad 2**.

Utilízalo únicamente si no has podido completar correctamente las actividades anteriores o si necesitas reincorporarte al proyecto.

Si tu propio Inventario Arcano funciona correctamente, continúa trabajando sobre él.

## Qué incluye

- Proyecto Spring Boot funcional.
- Controladores y vistas de la Actividad 1.
- Navegación y recursos visuales.
- Ruta base `/catalogo` mediante `@RequestMapping`.
- Consulta `/catalogo/objeto/{id}` con `@PathVariable` y varios `@RequestParam`.
- Búsqueda `/catalogo/buscar` con parámetros obligatorios, opcionales y valores por defecto.
- Consulta `/catalogo/rareza/{rareza}`.
- Conversión automática a `int`, `double` y `boolean`.
- Respuestas temporales mediante `@ResponseBody`.
- Enlaces de prueba desde la vista del catálogo.

## Importante

Este proyecto contiene solamente el **punto de partida necesario para la Actividad 3**.

No incluye la ampliación opcional de la Actividad 2 ni resuelve ningún apartado de la Actividad 3.

Ejecuta `InventarioArcanoApplication` y comprueba que la aplicación arranca antes de comenzar.
