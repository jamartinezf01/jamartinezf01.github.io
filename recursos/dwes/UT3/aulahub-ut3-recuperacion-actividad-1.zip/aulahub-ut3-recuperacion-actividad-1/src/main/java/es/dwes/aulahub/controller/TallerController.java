package es.dwes.aulahub.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TallerController {

    @GetMapping({"/", "/talleres"})
    public String mostrarTalleres() {
        return "talleres";
    }

    @GetMapping("/talleres/buscar")
    public String buscarTalleres(
            @RequestParam String texto,
            Model model) {

        model.addAttribute("texto", texto);
        return "resultado-busqueda";
    }

    @PostMapping("/talleres/inscripcion")
    public String procesarInscripcion(
            @RequestParam String nombre,
            @RequestParam String email,
            @RequestParam String taller,
            Model model) {

        model.addAttribute("nombre", nombre);
        model.addAttribute("email", email);
        model.addAttribute("taller", taller);

        return "resultado-inscripcion";
    }
}
