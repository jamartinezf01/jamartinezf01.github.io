# AulaHub · Recuperación de la Actividad 1 de UT3

Este proyecto contiene el **estado mínimo esperado al finalizar la Actividad 1** de la UT3 de DWES.

Incluye:

- página principal de AulaHub con sus recursos visuales y estilos;
- formulario de búsqueda mediante GET;
- recepción del parámetro `texto` con `@RequestParam`;
- vista con el criterio de búsqueda recibido;
- formulario de inscripción mediante POST;
- recepción de `nombre`, `email` y `taller` con `@RequestParam`;
- vista con los datos de inscripción recibidos.

No incluye contenidos de sesiones posteriores: no utiliza `@ModelAttribute`, `th:object`, `th:field`, Jakarta Validation, `@Valid` ni `BindingResult`.

Este ZIP sirve como punto de partida de recuperación para comenzar la **Actividad 2**.
