-- Ejecutar con una cuenta administradora de MySQL.
-- Sustituir la contraseña de ejemplo antes de ejecutar.
-- Ejecutar solo una vez en un entorno nuevo.
CREATE DATABASE rutas_culturales
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER 'rutas_app'@'%'
IDENTIFIED BY 'SUSTITUIR_POR_UNA_CONTRASENA_PROPIA';

GRANT ALL PRIVILEGES ON rutas_culturales.* TO 'rutas_app'@'%';
