-- Ejecutar DESPUÉS del primer arranque de Spring Boot, con las tablas creadas.
-- Una sola vez: los lugares tienen nombre único.
USE rutas_culturales;

INSERT INTO lugares (nombre, tipo, zona) VALUES
('Museo de la Ciudad', 'Museo', 'Centro histórico'),
('Teatro del Mercado', 'Teatro', 'Centro histórico'),
('Muralla Antigua', 'Monumento', 'Casco antiguo'),
('Archivo Histórico', 'Archivo', 'Centro histórico'),
('Jardín de Esculturas', 'Espacio artístico', 'Parque del Norte'),
('Galería del Puente', 'Galería', 'Ribera'),
('Biblioteca Patrimonial', 'Biblioteca', 'Centro histórico'),
('Plaza de los Artesanos', 'Plaza', 'Casco antiguo'),
('Antiguo Molino', 'Patrimonio industrial', 'Ribera'),
('Centro de Interpretación', 'Centro cultural', 'Parque del Norte');

INSERT INTO rutas (nombre, descripcion) VALUES
('Paseo por la memoria', 'Recorrido por la historia y el patrimonio local.'),
('Arte al aire libre', 'Ruta de espacios artísticos y lugares de encuentro.'),
('Cultura junto al río', 'Visita a espacios culturales de la ribera.');

SELECT id, nombre FROM rutas ORDER BY id;
SELECT id, nombre FROM lugares ORDER BY id;
