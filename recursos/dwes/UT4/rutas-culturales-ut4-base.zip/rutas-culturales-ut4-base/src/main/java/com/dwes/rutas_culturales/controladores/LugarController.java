package com.dwes.rutas_culturales.controladores;

import com.dwes.rutas_culturales.servicios.RutaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/lugares")
public class LugarController {
    private final RutaService servicio;

    public LugarController(RutaService servicio) { this.servicio = servicio; }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("lugares", servicio.listarLugares());
        return "lugares/lista";
    }
}
