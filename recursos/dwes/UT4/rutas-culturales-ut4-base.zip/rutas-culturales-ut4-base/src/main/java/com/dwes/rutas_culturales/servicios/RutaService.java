package com.dwes.rutas_culturales.servicios;

import com.dwes.rutas_culturales.formularios.RutaForm;
import com.dwes.rutas_culturales.modelo.Lugar;
import com.dwes.rutas_culturales.modelo.Ruta;
import com.dwes.rutas_culturales.repositorios.LugarRepository;
import com.dwes.rutas_culturales.repositorios.RutaRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class RutaService {
    private final RutaRepository rutas;
    private final LugarRepository lugares;

    public RutaService(RutaRepository rutas, LugarRepository lugares) {
        this.rutas = rutas;
        this.lugares = lugares;
    }

    public List<Ruta> listarRutas() { return rutas.findAllByOrderByNombreAsc(); }
    public Optional<Ruta> buscarRuta(Long id) { return rutas.findById(id); }
    public List<Lugar> listarLugares() { return lugares.findAllByOrderByNombreAsc(); }

    public Ruta crear(RutaForm form) {
        Ruta ruta = new Ruta();
        copiarDatos(ruta, form);
        return rutas.save(ruta);
    }

    public boolean actualizar(Long id, RutaForm form) {
        Optional<Ruta> encontrada = rutas.findById(id);
        if (encontrada.isEmpty()) return false;
        Ruta ruta = encontrada.get();
        copiarDatos(ruta, form);
        rutas.save(ruta);
        return true;
    }

    public boolean eliminar(Long id) {
        Optional<Ruta> encontrada = rutas.findById(id);
        if (encontrada.isEmpty()) return false;
        rutas.delete(encontrada.get());
        return true;
    }

    private void copiarDatos(Ruta ruta, RutaForm form) {
        ruta.setNombre(form.getNombre());
        ruta.setDescripcion(form.getDescripcion());
        // ACTIVIDAD 5: recuperar los lugares existentes y asignarlos a la ruta.
    }
}
