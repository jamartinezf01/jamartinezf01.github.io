package com.dwes.rutas_culturales.controladores;

import com.dwes.rutas_culturales.formularios.RutaForm;
import com.dwes.rutas_culturales.servicios.RutaService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/rutas")
public class RutaController {
    private final RutaService servicio;

    public RutaController(RutaService servicio) { this.servicio = servicio; }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("rutas", servicio.listarRutas());
        return "rutas/lista";
    }

    @GetMapping("/nuevo")
    public String mostrarNuevo(Model model) {
        model.addAttribute("ruta", new RutaForm());
        prepararFormulario(model, null);
        return "rutas/formulario";
    }

    @PostMapping("/nuevo")
    public String crear(@Valid @ModelAttribute("ruta") RutaForm form,
                        BindingResult errores, Model model,
                        RedirectAttributes redirect) {
        // ACTIVIDAD 5: comprobar que los IDs recibidos existen.
        if (errores.hasErrors()) {
            prepararFormulario(model, null);
            return "rutas/formulario";
        }
        servicio.crear(form);
        redirect.addFlashAttribute("mensaje", "Ruta creada correctamente.");
        return "redirect:/rutas";
    }

    @GetMapping("/{id}/editar")
    public String mostrarEditar(@PathVariable Long id, Model model,
                                RedirectAttributes redirect) {
        var encontrada = servicio.buscarRuta(id);
        if (encontrada.isEmpty()) {
            redirect.addFlashAttribute("error", "La ruta no existe.");
            return "redirect:/rutas";
        }
        model.addAttribute("ruta", RutaForm.desde(encontrada.get()));
        prepararFormulario(model, id);
        return "rutas/formulario";
    }

    @PostMapping("/{id}/editar")
    public String actualizar(@PathVariable Long id,
                             @Valid @ModelAttribute("ruta") RutaForm form,
                             BindingResult errores, Model model,
                             RedirectAttributes redirect) {
        // ACTIVIDAD 5: comprobar que los IDs recibidos existen.
        if (errores.hasErrors()) {
            prepararFormulario(model, id);
            return "rutas/formulario";
        }
        if (!servicio.actualizar(id, form)) {
            redirect.addFlashAttribute("error", "La ruta no existe.");
        } else {
            redirect.addFlashAttribute("mensaje", "Ruta actualizada correctamente.");
        }
        return "redirect:/rutas";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes redirect) {
        if (servicio.eliminar(id)) {
            redirect.addFlashAttribute("mensaje", "Ruta eliminada.");
        } else {
            redirect.addFlashAttribute("error", "La ruta no existe.");
        }
        return "redirect:/rutas";
    }

    private void prepararFormulario(Model model, Long idEdicion) {
        model.addAttribute("modoEdicion", idEdicion != null);
        model.addAttribute("idEdicion", idEdicion);
        // ACTIVIDAD 5: enviar aquí el catálogo de lugares al Model.
    }
}
