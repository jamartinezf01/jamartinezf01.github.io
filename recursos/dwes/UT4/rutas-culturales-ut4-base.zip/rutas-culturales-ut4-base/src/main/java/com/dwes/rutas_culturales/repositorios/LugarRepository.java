package com.dwes.rutas_culturales.repositorios;

import com.dwes.rutas_culturales.modelo.Lugar;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface LugarRepository extends JpaRepository<Lugar, Long> {
    List<Lugar> findAllByOrderByNombreAsc();
}
