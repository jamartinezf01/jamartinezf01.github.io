package com.dwes.rutas_culturales.repositorios;

import com.dwes.rutas_culturales.modelo.Ruta;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RutaRepository extends JpaRepository<Ruta, Long> {
    List<Ruta> findAllByOrderByNombreAsc();
    // ACTIVIDAD 5: adaptar las consultas para cargar lugares cuando se necesiten.
}
