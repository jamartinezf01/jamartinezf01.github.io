package com.dwes.rutas_culturales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RutasCulturalesApplication {
    public static void main(String[] args) {
        SpringApplication.run(RutasCulturalesApplication.class, args);
    }
}
