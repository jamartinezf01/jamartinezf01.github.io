package com.dwes.rutas_culturales.formularios;

import com.dwes.rutas_culturales.modelo.Ruta;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class RutaForm {
    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 120, message = "Máximo 120 caracteres")
    private String nombre;

    @NotBlank(message = "La descripción es obligatoria")
    @Size(max = 300, message = "Máximo 300 caracteres")
    private String descripcion;

    // ACTIVIDAD 5: añadir la lista de IDs de lugares seleccionados.

    public static RutaForm desde(Ruta ruta) {
        RutaForm form = new RutaForm();
        form.setNombre(ruta.getNombre());
        form.setDescripcion(ruta.getDescripcion());
        // ACTIVIDAD 5: preparar los lugares seleccionados al editar.
        return form;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
