# Proyecto base · Actividad 5: Organización de rutas culturales

Proyecto didáctico de DWES, UT4. **El reto N:M no está resuelto**: hay dos entidades independientes (`Ruta` y `Lugar`).

## Requisitos

- Java 21 y Maven (desde IntelliJ IDEA gratuito).
- MySQL accesible en `localhost:3306`. Puede estar instalado en el equipo o publicarse desde Docker.
- Spring Boot 4.1.2, Spring MVC, Thymeleaf, Spring Data JPA, Validation, MySQL Driver y DevTools.

## Preparación

1. Abre el proyecto desde `pom.xml` en IntelliJ y espera a que se carguen las dependencias Maven.
2. Accede a MySQL con una cuenta administradora y ejecuta **una sola vez** `sql/00-crear-base-datos.sql`. Cambia antes la contraseña de ejemplo y guarda la misma para `DB_PASSWORD`.
3. En IntelliJ, Run → Edit Configurations → Environment variables, configura `DB_PASSWORD` con la contraseña de `rutas_app`.
4. Arranca la aplicación. Hibernate crea las tablas `rutas` y `lugares`, inicialmente vacías (`spring.jpa.hibernate.ddl-auto=update`).
5. Accede a MySQL y ejecuta **una sola vez** `sql/01-datos-iniciales.sql`. Verifica que hay **10 lugares y 3 rutas**.
6. Abre `http://localhost:8080/rutas` y `http://localhost:8080/lugares`. Puedes crear, editar y eliminar rutas, pero todavía no asignar lugares.

**Si no tienes `mysql` en el host y trabajas con MySQL en Docker:** puedes usar `docker exec -it NOMBRE_CONTENEDOR_MYSQL mysql -u root -p` para los scripts de administración; y dentro del cliente usar `SOURCE` con una ruta accesible *dentro del contenedor*, o pegar las sentencias SQL.

## Organización

- `modelo/Ruta.java` y `modelo/Lugar.java`: entidades independientes; **no existe aún la relación N:M**.
- `repositorios/`: acceso a datos de cada entidad.
- `formularios/RutaForm.java`: datos de alta y edición de rutas.
- `servicios/RutaService.java`: lógica CRUD y acceso al catálogo de lugares.
- `controladores/`: CRUD de rutas, listado de lugares y redirección inicial.
- `templates/rutas/`: listado y formulario de rutas.
- `templates/lugares/lista.html`: catálogo de lugares (solo lectura).
- `static/css/rutas.css`: estilos, preparados también para checkboxes del reto.

## Lo que debe implementar el alumnado

- `@ManyToMany`, `@JoinTable` y `Set<Lugar>` desde `Ruta`.
- La tabla intermedia `ruta_lugares` con `ruta_id` y `lugar_id`.
- `List<Long> lugarIds` en `RutaForm`, su validación y la preparación de la edición.
- Resolución de IDs contra `LugarRepository` en el servicio, sin crear lugares al guardar rutas.
- Checkboxes en `templates/rutas/formulario.html` y visualización de lugares en el listado.
- Consultas que carguen los lugares que se mostrarán en la vista y al editar.
- Comprobaciones de integridad y eliminación de rutas sin borrar los lugares compartidos.

Hay comentarios `ACTIVIDAD 5` en los puntos relevantes del código y de las vistas. **No hay código de solución de la relación.**

## Precauciones

- Ejecuta los `INSERT` una sola vez. Los lugares son únicos y la segunda ejecución fallaría.
- Se utiliza `ddl-auto=update` para crear nuevas tablas durante la práctica. No uses `create` ni `create-drop`.
- Las rutas iniciales no tienen lugares. Al implementar el formulario, asígnales alguno mediante la edición.
- `spring.jpa.open-in-view=false` está configurado: carga expresamente las colecciones que necesite Thymeleaf.
- No uses cascadas de eliminación hacia `Lugar`. Un mismo lugar podrá pertenecer a varias rutas.
- MySQL `@'%'` sirve para facilitar conexiones locales/Docker en el laboratorio, no para exponer un servidor a Internet.
