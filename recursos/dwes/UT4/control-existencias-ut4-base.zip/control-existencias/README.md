# DWES · UT4 · Actividad 4 — Proyecto base de control de existencias

Este proyecto se entrega **antes de realizar la actividad**. Incluye el CRUD de `Articulo`,
la conexión a MySQL (a falta de configurar credenciales) y un script con diez artículos.
**No contiene** `Movimiento`, `MovimientoRepository`, la lógica de entradas/salidas ni el historial:
son el trabajo del alumnado.

## Preparación

1. Usar Java 21 e importar el proyecto Maven en IntelliJ IDEA gratuito.
2. Tener MySQL disponible en `localhost:3306` (instalación local o Docker con puerto publicado).
3. Ejecutar `sql/00-crear-base-datos.sql` con una cuenta administradora, sustituyendo la contraseña.
   Si la base o el usuario ya existen, revisar el estado antes de repetir comandos.
4. Configurar la variable `DB_PASSWORD` en Run → Edit Configurations → Environment variables.
5. Arrancar `ControlExistenciasApplication`. Hibernate crea la tabla `articulos` en la base vacía.
6. Ejecutar **una sola vez** `sql/01-articulos-iniciales.sql`.
7. Abrir `http://localhost:8080/articulos`.

Si usas Docker, puedes abrir MySQL con `docker exec -it <contenedor> mysql -u root -p`.
Tras crear las tablas, puedes cambiar `spring.jpa.hibernate.ddl-auto=update` a `validate`.

## Qué contiene

- Entidad `Articulo`: `id`, `codigo`, `nombre` y `stockActual`.
- Repositorio `ArticuloRepository`.
- Controlador y servicio CRUD de artículos.
- Validación básica: código/nombre obligatorios, código único y stock inicial no negativo.
- Plantillas Thymeleaf `articulos/lista.html` y `articulos/formulario.html`.
- Hoja `static/css/existencias.css`.
- Script con diez artículos iniciales.

## Atención

- El stock se indica al crear un artículo y **no puede editarse desde el formulario** existente.
  El servicio ignora `stockActual` al editar: los cambios posteriores se realizarán con movimientos.
- La eliminación de artículos del proyecto base funciona mientras no haya movimientos.
  El alumnado debe adaptarla para impedir borrar un artículo con historial registrado.
- `spring.jpa.open-in-view=false`: planifica la carga de las relaciones para las vistas.
- El proyecto base NO implementa transacciones para el registro de movimientos.
  Esa cuestión se estudiará en otro apartado.
- No hay Lombok, ni H2, ni datos de inicio automáticos.
