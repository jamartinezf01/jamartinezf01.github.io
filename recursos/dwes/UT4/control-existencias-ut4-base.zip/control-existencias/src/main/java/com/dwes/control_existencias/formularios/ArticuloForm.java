package com.dwes.control_existencias.formularios;

import com.dwes.control_existencias.modelo.Articulo;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ArticuloForm {

    @NotBlank(message = "El código es obligatorio")
    @Size(max = 20, message = "Máximo 20 caracteres")
    private String codigo;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 120, message = "Máximo 120 caracteres")
    private String nombre;

    @NotNull(message = "Indica las existencias iniciales")
    @Min(value = 0, message = "Las existencias no pueden ser negativas")
    private Integer stockActual;

    public static ArticuloForm desde(Articulo articulo) {
        ArticuloForm form = new ArticuloForm();
        form.setCodigo(articulo.getCodigo());
        form.setNombre(articulo.getNombre());
        form.setStockActual(articulo.getStockActual());
        return form;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public Integer getStockActual() { return stockActual; }
    public void setStockActual(Integer stockActual) { this.stockActual = stockActual; }
}
