package com.dwes.control_existencias.controladores;

import com.dwes.control_existencias.formularios.ArticuloForm;
import com.dwes.control_existencias.servicios.ArticuloService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/articulos")
public class ArticuloController {
    private final ArticuloService servicio;

    public ArticuloController(ArticuloService servicio) { this.servicio = servicio; }

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("articulos", servicio.listar());
        return "articulos/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model) {
        model.addAttribute("articulo", new ArticuloForm());
        prepararFormulario(model, null);
        return "articulos/formulario";
    }

    @PostMapping("/nuevo")
    public String crear(@Valid @ModelAttribute("articulo") ArticuloForm form,
                        BindingResult errores, Model model,
                        RedirectAttributes redirect) {
        comprobarCodigo(form, null, errores);
        if (errores.hasErrors()) {
            prepararFormulario(model, null);
            return "articulos/formulario";
        }
        servicio.crear(form);
        redirect.addFlashAttribute("mensaje", "Artículo añadido correctamente.");
        return "redirect:/articulos";
    }

    @GetMapping("/{id}/editar")
    public String editar(@PathVariable Long id, Model model, RedirectAttributes redirect) {
        var encontrado = servicio.buscarPorId(id);
        if (encontrado.isEmpty()) {
            redirect.addFlashAttribute("error", "El artículo no existe.");
            return "redirect:/articulos";
        }
        model.addAttribute("articulo", ArticuloForm.desde(encontrado.get()));
        prepararFormulario(model, id);
        return "articulos/formulario";
    }

    @PostMapping("/{id}/editar")
    public String guardar(@PathVariable Long id,
                          @Valid @ModelAttribute("articulo") ArticuloForm form,
                          BindingResult errores, Model model,
                          RedirectAttributes redirect) {
        comprobarCodigo(form, id, errores);
        if (errores.hasErrors()) {
            prepararFormulario(model, id);
            return "articulos/formulario";
        }
        if (!servicio.actualizar(id, form)) {
            redirect.addFlashAttribute("error", "El artículo no existe.");
        } else {
            redirect.addFlashAttribute("mensaje", "Artículo actualizado correctamente.");
        }
        return "redirect:/articulos";
    }

    @PostMapping("/{id}/eliminar")
    public String eliminar(@PathVariable Long id, RedirectAttributes redirect) {
        if (servicio.eliminar(id)) {
            redirect.addFlashAttribute("mensaje", "Artículo eliminado correctamente.");
        } else {
            redirect.addFlashAttribute("error", "El artículo no existe.");
        }
        return "redirect:/articulos";
    }

    private void prepararFormulario(Model model, Long idEdicion) {
        model.addAttribute("modoEdicion", idEdicion != null);
        model.addAttribute("idEdicion", idEdicion);
    }

    private void comprobarCodigo(ArticuloForm form, Long idEdicion, BindingResult errores) {
        if (form.getCodigo() != null && servicio.codigoDuplicado(form.getCodigo(), idEdicion)) {
            errores.rejectValue("codigo", "codigo.duplicado", "Ese código ya está en uso");
        }
    }
}
