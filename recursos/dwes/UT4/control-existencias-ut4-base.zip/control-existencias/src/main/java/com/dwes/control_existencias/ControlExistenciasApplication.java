package com.dwes.control_existencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControlExistenciasApplication {
    public static void main(String[] args) {
        SpringApplication.run(ControlExistenciasApplication.class, args);
    }
}
