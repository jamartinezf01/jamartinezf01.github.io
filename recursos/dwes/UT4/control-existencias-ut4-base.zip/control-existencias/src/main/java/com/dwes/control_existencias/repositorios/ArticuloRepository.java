package com.dwes.control_existencias.repositorios;

import com.dwes.control_existencias.modelo.Articulo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ArticuloRepository extends JpaRepository<Articulo, Long> {
    List<Articulo> findAllByOrderByNombreAsc();
    boolean existsByCodigo(String codigo);
    boolean existsByCodigoAndIdNot(String codigo, Long id);
}
