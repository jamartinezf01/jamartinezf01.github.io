package com.dwes.control_existencias.servicios;

import com.dwes.control_existencias.formularios.ArticuloForm;
import com.dwes.control_existencias.modelo.Articulo;
import com.dwes.control_existencias.repositorios.ArticuloRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ArticuloService {
    private final ArticuloRepository articulos;

    public ArticuloService(ArticuloRepository articulos) {
        this.articulos = articulos;
    }

    public List<Articulo> listar() { return articulos.findAllByOrderByNombreAsc(); }
    public Optional<Articulo> buscarPorId(Long id) { return articulos.findById(id); }

    public boolean codigoDuplicado(String codigo, Long idEdicion) {
        if (codigo == null) return false;
        return idEdicion == null
                ? articulos.existsByCodigo(codigo)
                : articulos.existsByCodigoAndIdNot(codigo, idEdicion);
    }

    public Articulo crear(ArticuloForm form) {
        Articulo articulo = new Articulo();
        articulo.setCodigo(form.getCodigo());
        articulo.setNombre(form.getNombre());
        articulo.setStockActual(form.getStockActual());
        return articulos.save(articulo);
    }

    public boolean actualizar(Long id, ArticuloForm form) {
        Optional<Articulo> encontrado = articulos.findById(id);
        if (encontrado.isEmpty()) return false;
        Articulo articulo = encontrado.get();
        articulo.setCodigo(form.getCodigo());
        articulo.setNombre(form.getNombre());
        // El stock no se cambia desde la edición de un artículo.
        // En la Actividad 4, solo se modificará al registrar movimientos.
        articulos.save(articulo);
        return true;
    }

    public boolean eliminar(Long id) {
        Optional<Articulo> encontrado = articulos.findById(id);
        if (encontrado.isEmpty()) return false;
        // A adaptar por el alumnado cuando existan movimientos:
        // no borrar artículos con historial.
        articulos.delete(encontrado.get());
        return true;
    }
}
