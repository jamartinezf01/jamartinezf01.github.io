-- Ejecutar UNA SOLA VEZ después de arrancar el proyecto (para crear articulos).
USE control_existencias;

INSERT INTO articulos (codigo, nombre, stock_actual) VALUES
('ART-001', 'Ratón USB', 25),
('ART-002', 'Teclado USB', 18),
('ART-003', 'Cable HDMI 2 m', 30),
('ART-004', 'Memoria USB 32 GB', 22),
('ART-005', 'Adaptador USB-C', 12),
('ART-006', 'Auriculares con micrófono', 9),
('ART-007', 'Cable de red 3 m', 40),
('ART-008', 'Regleta de seis tomas', 8),
('ART-009', 'Alfombrilla de ratón', 35),
('ART-010', 'Webcam USB', 6);

SELECT id, codigo, nombre, stock_actual FROM articulos ORDER BY codigo;
