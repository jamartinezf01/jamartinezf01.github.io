-- Ejecutar con una cuenta administradora de MySQL, una sola vez.
-- Elegir y sustituir una contraseña propia.
CREATE DATABASE control_existencias
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE USER 'existencias_app'@'%'
IDENTIFIED BY 'SUSTITUIR_POR_UNA_CONTRASENA_PROPIA';

GRANT ALL PRIVILEGES ON control_existencias.*
TO 'existencias_app'@'%';
